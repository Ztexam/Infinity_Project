"""Explicitly allowlisted source and optional AES-GCM encrypted connection ZIPs."""
import argparse
import hashlib
import json
from pathlib import Path
import secrets
import sys
import zipfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def portable_files():
    names = ['start.py', 'portable.py', 'requirements-portable.txt', 'Start Shortlist.cmd',
             'Start Shortlist.command', 'start.sh', 'PORTABLE_SETUP.md', 'READ_ME_FIRST.txt',
             'Dockerfile', '.dockerignore', 'compose.yaml', 'frontend/live.html',
             'connection/README.txt', 'docs/ORCHESTRATE_EMBED.md',
             'docs/ORCHESTRATE_AGENT_UPDATE.md', 'docs/agent-behavior-change-2026-11-19.json',
             'docs/qa-portable-performance-2026-11-19.json', 'docs/qa-portable-connection-2026-11-19.json']
    files = [ROOT / name for name in names]
    for folder, pattern in [('poc', '*.py'), ('service', '*.py'), ('tests', 'test_*.py'), ('data', '*.json')]:
        files.extend(sorted((ROOT / folder).glob(pattern)))
    files.append(ROOT / 'service/additional_employers.json')
    files.extend([ROOT / 'deploy/package_portable.py'])
    return files


def build_bundle(target, connection=None):
    files = portable_files()
    contents = {path.relative_to(ROOT).as_posix(): path.read_bytes() for path in files}
    if connection is not None:
        contents['connection/ibm-connection.enc'] = connection
    manifest = {'format': 'infinity-portable-v1', 'created_at': datetime.now(timezone.utc).isoformat(),
                'encrypted_connection_included': connection is not None,
                'python_requirement': '3.11+', 'files': {name: hashlib.sha256(data).hexdigest() for name, data in contents.items()}}
    contents['MANIFEST.json'] = json.dumps(manifest, indent=2).encode()
    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as bundle:
        for name, content in contents.items():
            info = zipfile.ZipInfo('Infinity_Project/' + name)
            info.create_system = 3
            info.external_attr = (0o100755 if name in ('start.sh', 'Start Shortlist.command') else 0o100644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            bundle.writestr(info, content)
    return manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--with-connection', action='store_true')
    parser.add_argument('--config-dir', type=Path)
    args = parser.parse_args()
    connection = None
    password_file = None
    if args.with_connection:
        from portable import config_directory, encrypted_connection, private_write
        directory = args.config_dir or config_directory()
        password = secrets.token_urlsafe(24)
        connection = encrypted_connection(directory, password)
        # Migrate the legacy local SEC identifier to private settings for the new launcher.
        settings = directory / 'portable-settings.json'
        if not settings.is_file():
            import os
            private_write(settings, json.dumps({'sec_user_agent': os.environ['SEC_USER_AGENT']}).encode())
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-%f')
        password_file = config_directory().parent / 'portable-backups' / ('transfer-password-' + stamp + '.txt')
        private_write(password_file, password.encode('ascii'))
    build_bundle(ROOT / 'dist/Infinity_Project_Source.zip')
    target = ROOT / 'dist/Infinity_Project_Portable.zip'
    manifest = build_bundle(target, connection)
    print('Portable ZIP: ' + str(target))
    print('Code-only ZIP: ' + str(ROOT / 'dist/Infinity_Project_Source.zip'))
    print('Files: ' + str(len(manifest['files'])) + '; encrypted connection included: ' + str(connection is not None))
    if password_file:
        print('Transfer password saved separately (keep private): ' + str(password_file))
    print('SHA256: ' + hashlib.sha256(target.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
