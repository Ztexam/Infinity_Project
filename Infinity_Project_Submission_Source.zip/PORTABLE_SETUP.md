# Infinity Job Shortlist: portable setup

## What moves, and what stays in IBM

The ZIP contains the frontend, Python collector, 72 employer feeds, financial rules, tests, and launchers. Python 3.11+ and Internet are required; this is a portable source application, not a bundled Python executable. First launch creates `.portable-venv` and installs pinned `cryptography` and `waitress` packages from PyPI. Later launches reuse that environment. Do not copy virtual environments between machines.

The two AI agents remain deployed in the existing Frankfurt **watsonx-Hackathon Orchestrate** instance. The lead is **Infinity Job Shortlist** (`1c5a5f53-11a0-45fe-bb35-0e09ccc3d245`), with **Infinity Company Assessment** (`a3d7e565-a68d-4605-8b59-b4fcfab80c62`) as its deployed collaborator. Both are version 1.1.0 at this checkpoint. Keeping the lead ID, live environment and signed connection preserves the collaboration. The app does not copy agents into another IBM account or operate offline. No IBM API key or Bob IDE is required. IBM trial/usage limits still belong to the existing account, independently of Bobcoins.

## Move to a Windows, macOS or Linux computer

1. Transfer `Infinity_Project_Portable.zip`. Obtain its **separate transfer-password file** from the original owner through a private channel; do not put it in the ZIP or chat.
2. Extract the ZIP to a writable folder. Install [Python 3.11+](https://www.python.org/downloads/) if needed. Windows users should enable the Python launcher or add Python to PATH.
3. Windows: double-click **Start Shortlist.cmd**. macOS: double-click **Start Shortlist.command**; if it is not executable, open Terminal in the extracted folder and run `sh start.sh`. Linux: run `sh start.sh`.
4. The first launch asks for the transfer password with hidden input. It decrypts the existing connection into your user configuration folder and restricts file permissions. This happens once. No IBM sign-in or new key registration is normally needed for the same `http://localhost:8080` origin.
5. The browser opens **http://localhost:8080/live**. Keep the launcher running; Ctrl+C stops the app. On a headless computer, add `--no-browser`.

If a matching local server is already running, the launcher opens it. Use `http://localhost:8080`, not a different hostname/port, because IBM registered that exact development origin. The numeric loopback URL redirects to localhost in local mode. To verify a new restored installation without invoking an agent, run `python start.py doctor`.

### Search and speed

Enter one or two keywords and a location, or **United States — all 50 states**. Keep Focus and Experience at Any to avoid narrowing results. **Quick search — refresh after 15 min** is the default: it reuses recent employer and discovery data, refreshes expired/missing data and caches financial sources for 24 hours. **Check employer boards now** forces all feeds to refresh. **Use cached** explicitly allows older saved data, with collection dates shown. Failed/stale data is not silently called live. Job data preparation time appears before the two IBM agents finish reviewing.

Collection uses eight workers; keyword/location discovery overlaps board collection and has four workers. Greenhouse and Lever have separate request pacing; SEC stays conservatively rate limited. A cold first collection and slow/unavailable providers can still take time. The agents remain sequential because the shortlist depends on the financial assessment. Their inference latency is outside the Python collector.

In the local Windows check, the keyword-matching preparation dropped from 1.86 seconds to about 0.35 seconds for the same cached dataset. A warm Quick search prepared data in about 0.7 seconds. A cold refresh still took 40 seconds, plus the separate IBM review. These are observed examples, not speed guarantees. Profiling, exact result comparisons and connection checks are saved in `docs/qa-portable-performance-2026-11-19.json` and `docs/qa-portable-connection-2026-11-19.json`.

## Run on a server without changing IBM origins

Recommended for a personal demo: keep the app private on the server and use an SSH tunnel. On the server:

```sh
sh start.sh setup
sh start.sh --no-browser
```

On your own computer:

```sh
ssh -N -L 8080:127.0.0.1:8080 your-user@your-server
```

Open **http://localhost:8080/live** on your computer. This uses IBM's already registered origin and requires no IBM API key or repeated local app token. Port 8080 must be free on both ends. Do not open a firewall port for this approach.

For a browser-accessible remote website, run `sh start.sh --server --no-browser` behind your own HTTPS reverse proxy. Server mode binds to `0.0.0.0` and requires an **app access token**, stored in the private connection directory as `app-access-token.txt`; enter it into the app's operator field. This is a local application credential, not an IBM API key. You must register the exact HTTPS origin in IBM Embed Security before using agents on that domain. This package does not expose a public site, add origins, weaken authentication or provision cloud resources. Keep the signing key server-side. Use one service process because source operations are serialized within that process.

## Optional Docker

From the extracted personal ZIP, on a machine with Docker Engine/Compose running:

```sh
docker compose build
docker compose run --rm -it shortlist setup
docker compose up -d
docker compose logs -f shortlist
```

Setup asks for the separate transfer password and stores the restored connection and generated app token in the persistent `shortlist_state` volume. The container runs as a non-root user. By default the port is published only on `127.0.0.1:8080`. Docker server mode requires the app access token, including when accessed through a tunnel. To display it on your own terminal (never paste it into chat):

```sh
docker compose exec shortlist python -c "from portable import config_directory; print((config_directory()/'app-access-token.txt').read_text())"
```

Paste it into the app's operator access field. `docker compose down` stops the service but keeps the volume. Do not remove the volume unless you intend to delete the restored connection and cache. Docker runtime availability must be verified on the target; the Docker daemon was not running on the original Windows machine during packaging.

## Connection files and recovery

The personal ZIP includes `connection/ibm-connection.enc`: an AES-256-GCM encrypted backup, with a random salt and nonce and PBKDF2-SHA256 password derivation. The separate transfer-password file is protected for the original OS user. Decryption validates the RSA key and public IBM widget fields before writing files. It never imports the old Windows DPAPI demo token; each installation generates its own app token. Re-import refuses to overwrite an existing connection.

Default private connection folders:

| System | Folder |
| --- | --- |
| Windows | `%LOCALAPPDATA%/InfinityProject/orchestrate-embed` |
| macOS | `~/Library/Application Support/InfinityProject/orchestrate-embed` |
| Linux | `$XDG_CONFIG_HOME/InfinityProject/orchestrate-embed` or `~/.config/InfinityProject/orchestrate-embed` |

Use `--config-dir PATH` on a launcher command, or set `SHORTLIST_CONFIG_DIR`, to choose another private folder. `CACHE_DIR` optionally relocates the data cache; otherwise it is under the extracted project's `runtime_cache/ibm`. Neither plaintext keys, transfer passwords, `.env`, virtual environments, machine-specific caches nor old DPAPI tokens are included in the ZIP. The code-only `Infinity_Project_Source.zip` excludes even the encrypted connection backup and is the version to share publicly.

To export a fresh password-protected connection from an already configured installation:

```sh
python start.py export-connection my-ibm-connection.enc
```

To import an explicitly selected backup into a new configuration directory:

```sh
python start.py setup --import-file my-ibm-connection.enc --config-dir ./private-connection
python start.py run --config-dir ./private-connection
```

If the transfer password is lost, export again from a working original installation. A lost original signing key cannot be recovered from the code-only ZIP; an IBM administrator must register a replacement and update the connection. A revoked/expired IBM instance or deleted collaborator also requires IBM account access. The app does not bypass IBM access or trial limits.

## Validation and rebuild

Run `python -m unittest discover -s tests -v` and `python -m poc check` using the app's Python environment. `MANIFEST.json` lists SHA-256 hashes for the packaged files. Run `python deploy/package_portable.py --with-connection` from the original configured machine to build both ZIPs and write a new separate protected transfer-password file. The backup and password are sensitive even though the backup is encrypted.

Windows relocation, the `.cmd` launcher with Python 3.13, encrypted restore, signed token creation and a real two-agent browser search were tested. The 36 automated checks passed. macOS/Linux launcher code and Docker Compose configuration are included, but native macOS/Linux execution and a Docker image build/run were not tested on this machine. The Docker daemon was unavailable. The portable ZIP does not promise support for devices without a compatible Python interpreter and browser.
