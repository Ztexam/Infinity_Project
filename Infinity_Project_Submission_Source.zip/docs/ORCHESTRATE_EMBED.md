# Signed shortlist chat record

On November 10, 2026, the Frankfurt (`eu-de`) **watsonx-Hackathon Orchestrate** instance was configured to accept signed chat sessions from the local shortlist app. The app runs at `http://localhost:8080/live`. IBM requires the literal `localhost` hostname for HTTP development origins. The first configuration request with the numeric loopback address returned HTTP 422. The request with `http://localhost:8080` returned HTTP 200 and a read-back confirmed the saved setting.

| Setting | Before | After |
| --- | --- | --- |
| Embed security | Enabled | Enabled |
| Allowed origins | Empty | `http://localhost:8080` |
| Client public key | Absent | Local 4096-bit RSA public key registered |
| IBM-managed key | Absent | Generated and registered in Orchestrate |

The one-time configuration used the existing IBM Cloud Shell session's IAM bearer token. The browser uses ten-minute RS256 tokens minted by the Python service after local demo authentication. The app's private signing key and Live widget configuration are in `%LOCALAPPDATA%\InfinityProject\orchestrate-embed`. The Windows user protects the local demo token with DPAPI. The SHA-256 of `client-public.pem` on this machine is `69E5A8C75A0DD0811C55B0090A9E8B99D7C159911BF9B500ACA67328D79AA67C`. [IBM embed security setup](https://www.ibm.com/docs/en/watsonx/watson-orchestrate/base?topic=chat-configuring-security-embedded)

## Start or reopen the app

Double-click **Start Shortlist.cmd** in the project folder. The portable launcher now creates its own Python environment, installs its dependencies, starts Waitress and opens the browser. Python 3.11+ is required. Leave the launcher window open while using the app. If the server is already running, open `http://localhost:8080/live`. See [portable setup](../PORTABLE_SETUP.md) for another computer or server.

The PowerShell command below is the **legacy launcher**, retained in the original source project. It is not required by the portable ZIP.

```powershell
pwsh -File .\Run-Shortlist.ps1
```

Local browser requests use the same `localhost` origin without a pasted token. The portable launcher's server-mode operator token is stored privately as `app-access-token.txt` in the connection folder. The command below copies the **legacy PowerShell launcher's** DPAPI token; it does not authenticate a server started with the new portable launcher.

```powershell
pwsh -File .\Run-Shortlist.ps1 -CopyDemoToken
```

Enter one or two comma-separated keywords, set **Location** and optionally **Second location**, then click **Find jobs**. **Check employer boards now** refreshes the configured boards and runs up to four queries through the [free VeritaHire U.S. search](https://veritahire.com/developers/). Python checks each result against the location published on the posting and looks for filings under an unambiguous employer name in the SEC issuer directory. **Top scored openings** shows up to ten eligible jobs, including multiple roles at an employer. **All matching job links** includes every matching link the app collected. **Show Reasoning → Step 1** displays the collaborator call.

The financial score uses four fiscal quarters when the required data is available. A verified half-year report can also qualify using the latest six months and the same six months a year earlier. The app labels the period beside each score and applies the positive operating cash flow and above-5 requirements to that period. The half-year score omits the quarter-by-quarter cash flow adjustment because six-month totals do not establish quarterly results.

## Verified run

- November 10, 2026 at 10:29 p.m. Pacific, from the app's **Run both agents** button.
- Lead **Infinity Job Shortlist** called `chat_with_collaborator_infinity_company_assessment`. Its trace included the latest quarter end of September 30, 2026, four-quarter operating cash flow of $1,327,854,000 positive in all four quarters, 28.37% cash-flow margin, 15.38% revenue growth, 17.46% R&D growth, and the SEC filing.
- The embedded chat marked [Pinterest Principal Engineer, Big Data Platform](https://www.pinterestcareers.com/jobs/?gh_jid=7683981) eligible with a 10/10 score and cited the [SEC filing](https://www.sec.gov/Archives/edgar/data/1506293/000150629326000153/pins-20260930.htm). The source data was within the app's freshness windows. The run used the signed embed and no IBM API key or Bob call.

## Follow-up consistency tests

On November 10, 2026, three additional listings ran from **Run both agents** in separate embedded chats at `http://localhost:8080/live`. All three traces showed **Infinity Job Shortlist** calling `chat_with_collaborator_infinity_company_assessment`. Each handoff carried the reporting period, cash flow and margin, revenue and R&D growth, score, and filing URL. The runs used the signed embed without an IBM API key or Bob call.

| Listing | Inputs | Expected | Observed |
| --- | --- | --- | --- |
| [Cloudflare, Senior Software Engineer, Durable Objects](https://boards.greenhouse.io/cloudflare/jobs/5390243?gh_jid=5390243) | Rust and TypeScript. SEC figures for the four quarters ending September 30, 2026 showed $681,670,000 in operating cash flow. [Filing](https://www.sec.gov/Archives/edgar/data/1477333/000147733326000061/cloud-20260930.htm) | Eligible at 10/10 | Eligible. The result cited the listing and filing. |
| [Fastly, Senior Engineer, Network Management Platform](https://www.fastly.com/about/jobs/apply?gh_jid=7858609) | Kubernetes, Go, and AWS. SEC figures for the four quarters ending September 30, 2026 showed $130,615,000 in operating cash flow. [Filing](https://www.sec.gov/Archives/edgar/data/1517413/000151741326000345/fsly-20260930.htm) | Eligible at 9/10 | Eligible. The result cited the listing and filing. |
| Braze, Staff Machine Learning Engineer, ML Platform (`braze:8209438`) | Machine learning. **Synthetic QA financial inputs** used $70 million in operating cash flow, a 7% margin, 12% year-over-year revenue decline, and 5% R&D growth. Cash flow was positive in all four quarters. | Reject at exactly 5/10 despite positive cash flow | Rejected. The response said eligibility requires a score strictly above 5. |

Every company in the available dataset cleared the eligibility rule, so the boundary case used a real listing with hypothetical financials in a temporary copy of the app's data. Cloudflare and Fastly used collected SEC data within the freshness windows. The Braze picker and submitted prompt identified the case as QA, but the collaborator handoff and final reply dropped that label. The Braze result therefore serves only as evidence of threshold behavior. After restoring the regular app, its prepare endpoint returned the actual collected-data score of 9/10 for Braze and rejected the temporary QA token.

## Live company shortlist

On November 10, 2026, the revised **Find companies** flow was tested in Chrome with `Scala, TypeScript`, **Backend**, and **Staff / Principal**. One click checked all 10 configured employer boards and found three openings across two companies. The signed chat opened without a pasted demo token. **Show Reasoning → Step 1** showed **Infinity Job Shortlist** sending both companies' SEC evidence to **Infinity Company Assessment** in one call.

The final response ranked Pinterest and Reddit, gave both a financial confidence score of 10/10, and displayed one recommended opening, an application link, and a filing link for each company. The app also displayed application and filing links directly from the source records. The offline test suite passed 25 tests, including checks for live job board refresh and local browser access.

Two consecutive searches in the same Chrome tab later that evening tested the conversation reset and city filter. Each search successfully checked all ten employer boards and kept the **Backend** and **Staff / Principal** filters. The `Scala` search in San Francisco displayed two Pinterest source links and the agents recommended the [Principal Engineer, Big Data Platform listing](https://www.pinterestcareers.com/jobs/?gh_jid=7683981). Editing the filters cleared those links. The `Kubernetes` search in Seattle returned one matching listing and the new chat ranked MongoDB after calling **Infinity Company Assessment**. The source link opened the [MongoDB Staff Site Reliability Engineer, Infrastructure Security posting](https://www.mongodb.com/careers/jobs/6982487). Both searches used signed chat without an IBM API key or Bob call.

The `HRIS, Programing` search in `New Jersey` initially returned no openings because it used literal keyword matching and the collector excluded HR systems titles. After the update, a live run checked all ten boards and the signed chat shortlisted [MongoDB Senior Software Engineer, Deployments](https://www.mongodb.com/careers/jobs/7727910), citing the posting's “software development” requirement. The trace confirmed the finance collaborator call. The refreshed boards returned no HRIS matches in New Jersey when searched for HRIS alone.

On November 11, 2026, the live app added six public Greenhouse feeds. With **New Jersey** selected and all 16 feeds responding, `HRIS` found five openings at three employers and `Python` found 26 at five employers. The Python results showed all 26 job links and both agents assessed CoreWeave and MongoDB using SEC evidence. Employers without supported financial evidence displayed their direct links with **Financial review unavailable**.

The next expansion added 39 free feeds, bringing the total to 55 across Greenhouse and Lever. Both live New Jersey searches checked all 55 boards successfully. `HRIS` found six openings across four employers. The agents reviewed [Legend Biotech's SEC filings](https://www.sec.gov/Archives/edgar/data/1801198/000180119826000026/legn-20260930.htm) and excluded it from the ranked shortlist at 3.8/10 with negative four-quarter operating cash flow. `Python` found 35 openings across nine employers, with quarterly assessments for CoreWeave, Datadog, and MongoDB. A repeat using the saved job listings confirmed that the collaborator received [GenScript's HKEX half-year report](https://www1.hkexnews.hk/listedco/listconews/sehk/2026/0916/2026091600223.pdf) and that the chat displayed the interim figures without a quarterly score. All 29 tests passed.

A live search for `HRIS, Python` across `New Jersey` and `Philadelphia, PA` checked all 55 boards and completed all four VeritaHire queries. It returned 51 unique openings, including 11 from VeritaHire. The app now uses GenScript's comparative half-year figures and reported operating cash flow to score it at 6/10. The top list can include multiple openings at each employer. A repeat using saved listings verified that the strongest eligible role in Philadelphia appears alongside the New Jersey openings. The agents' chat still grouped its final summary by employer in that repeat. All 30 tests passed.

## Nationwide QA — November 19, 2026

The app now accepts **United States — all 50 states**, **United States**, or **Nationwide** in Location. Leave Second location blank. Individual state and city searches remain available. Nationwide results require U.S. evidence in the employer's published location fields; this searches the available feeds across the country and does not establish that every state currently has a matching opening.

There are now **72 free public employer feeds**: the original ten and 62 additional feeds. The first 70-board regional search successfully fetched all 70. The final nationwide Python HTTP check fetched 70 of 72 feeds successfully (Braze and Palantir failed), completed the discovery search, found **761 matching openings at 95 employers**, and produced **ten distinct scored application links**. Results change with source availability. The preceding browser run found 765 at 86 employers with 68 of 70 feeds responding. Its ten displayed application links were verified: seven returned the matching posting over HTTP, both CoreWeave roles loaded their matching Greenhouse application iframe, and Rubrik's matching application page loaded in the browser despite blocking the HTTP client.

The final HTTP result also included Oracle's HRIS Analyst 2, whose exact application URL returned HTTP 200 and contained the matching title. All ten distinct application URLs in the final recorded shortlist were verified through HTTP or the browser.

The browser run's **Show Reasoning → Step 1** explicitly named `chat_with_collaborator_infinity_company_assessment`, confirming both deployed agents participated through signed embedded chat without an IBM API key. The final chat produced ten openings but substituted a different opening for the second CoreWeave role and wrongly questioned GenScript's six-month evidence. These are **outstanding deployed-agent instruction defects**, not a passed consistency test. IBM's agent editor redirected to sign-in; no deployment change was made. Sign in there to apply [the prepared behavior corrections](ORCHESTRATE_AGENT_UPDATE.md), redeploy the two existing agents and run one final verification.

The local handoff now supplies cash-flow margin, year-over-year revenue and R&D changes, positive period cash flow, and eligibility for six-month evidence, without inventing quarterly consistency. Query-specific discovery snapshots survive app restarts and failed refreshes and are restored only when **Use cached** is selected. All **31 tests** and the original snapshot/scoring check passed. No Bob call was made. IBM embedded inference is separate from Bobcoins; its billed usage was not independently checked here. See [the final structured local result](qa-nationwide-2026-11-19.json) and [the earlier browser screenshot](qa-nationwide-2026-11-19.jpg).

## Deployed-agent correction and successful verification — November 19, 2026

After the user signed in, both existing agents were updated and deployed as **1.1.0** in the same Frankfurt Hackathon Orchestrate instance. Company Assessment became Live at **2:46 p.m. Pacific** and Job Shortlist at **2:48 p.m. Pacific**. The lead's deployment summary included its existing Company Assessment collaborator. The 1.0.0 versions remain available for rollback, and [the exact before/after instructions](agent-behavior-change-2026-11-19.json) are saved locally.

The fresh HRIS/Python search for **United States — all 50 states**, with Focus and Experience set to Any, fetched **72 of 72 boards**, completed both discovery queries, and found **856 matching openings across 96 employers**, including 41 discovery results. The first agent run kept separate CoreWeave roles but substituted other jobs and emitted angle-bracket URLs that the widget did not display. The Python handoff was repaired to include complete ranked records with explicit ranks, to omit substitute job examples for other employers, and to request named Markdown links. Financial rules and scores were unchanged.

The verification repeat deliberately used **Use cached**, reusing that just-collected live dataset rather than fetching or implying a second live collection. The signed embedded run returned **ten application links and ten financial report links**, all in the app's exact ranked order. It kept both CoreWeave roles and included Oracle's HRIS Analyst 2. Every listed score was the supplied 10/10; these are provisional rubric scores. **Show Reasoning → Step 1** named `chat_with_collaborator_infinity_company_assessment`. Its message included the top-opening order and GenScript's complete comparative six-month amounts, derived ratios, 6/10 score and report URL. The final chat explicitly marked **GenScript eligible at 6/10 for the six months ended June 30, 2026**, with quarterly consistency not required. GenScript remained outside the ten higher-scoring job entries.

Six application pages returned HTTP 200 with the matching title. Both CoreWeave roles rendered their matching Greenhouse application iframes; Pinterest and Rubrik rendered their matching job heading and application section in the browser despite HTTP-client blocks. No application was submitted. The local suite still passed **31 tests** plus the original snapshot/scoring check. No Bob call or IBM API key was used. Existing signed authentication and cloud resources were preserved.

The full [QA record](qa-agents-nationwide-after-deploy-2026-11-19.json) preserves both attempts, copied replies, collaborator traces, exact ranked jobs and link checks. Screenshots show [the lead deployment](qa-agent-deployment-2026-11-19.jpg), [the financial deployment](qa-financial-agent-deployment-2026-11-19.jpg), [the ranked cards](qa-top-ten-verified-2026-11-19.jpg), and [six-month acceptance](qa-six-month-accepted-2026-11-19.jpg). This successful result supersedes the pending-login and deployed-instruction defects described in the earlier historical section.

## Portable connection verification — November 19, 2026

The project was extracted into a different Windows directory with spaces and bootstrapped through the `.cmd` launcher with Python 3.13.3. An AES-GCM encrypted backup restored the existing signing key and public widget fields into a separate private configuration directory. The old DPAPI token was not copied. A real signed embedded search from the moved installation called the financial collaborator, returned ten application links and ten report links in the exact card order, and accepted GenScript's six-month evidence at 6/10. The run used Quick search, refreshed expired data, and found 852 openings across 95 employers. Warm Quick search preparation then took roughly 0.7 seconds, excluding IBM inference. No IBM API key or Bob call was used. See [the relocation record](qa-portable-connection-2026-11-19.json), [timings](qa-portable-performance-2026-11-19.json) and [setup steps](../PORTABLE_SETUP.md).

The ZIP includes an encrypted connection backup only in the personal edition, and its transfer password is stored separately with restricted local file permissions. The code-only edition omits the encrypted backup. The existing localhost origin continues to work on a new computer or through an SSH tunnel; a new public HTTPS domain needs a deliberate IBM allowed-origin update. No such authentication-setting change was made here. Docker Compose configuration validated, but Docker runtime and native macOS/Linux execution were not available on this machine. The 36 automated checks passed.

## Revert or move the integration

For a local-only revert, stop the signed launcher and start `python -m service serve` with the usual local demo token and without the two `ORCHESTRATE_EMBED_*` settings. The manual **Open in IBM Chat instead** flow is available in that mode. The IBM registration is separate. If the integration is retired, use IBM's embed security administration to remove the registered client trust and local origin while keeping embed security enabled. The table above records the starting state. A new app host needs its own approved origin and a fresh signed-chat test.
