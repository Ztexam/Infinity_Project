"""Source, API and IBM protocol fixtures. These never impersonate live AI runs."""
from datetime import datetime, timedelta, timezone
import base64
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from poc.backend import AgentError, ROOT, matching_skill_phrases
from service.app import Application
from service.engine import STATE_NAMES, Engine, LiveJobSystem, match_location, validate_profile
from service.http_client import JsonHTTP, SourceError
from service.sources import IFRS_FORMS, add_inline_ifrs_facts, lever_jobs, normalize_financials, normalize_jobs, quarter_values, utcnow
from service.store import Store
from service.watsonx import WatsonxClient


def fixture_financials(company_id='cloudflare'):
    company = next(c for c in json.loads((ROOT / 'data/companies.json').read_text())['companies'] if c['company_id'] == company_id)
    record = next(c for c in json.loads((ROOT / 'data/financials.json').read_text())['companies'] if c['company_id'] == company_id)
    facts = {'cik': int(company['cik']), 'facts': {'us-gaap': {}}}
    for fact in record['source_facts'].values():
        tag = facts['facts']['us-gaap'].setdefault(fact['tag'], {'units': {'USD': []}})
        tag['units']['USD'].append({'start': fact['period_start'], 'end': fact['period_end'],
            'val': fact['value'], 'form': fact['form'], 'filed': fact['filed_at'], 'accn': fact['accession_number']})
    filing = record['latest_periodic_filing']
    submissions = {'filings': {'recent': {'form': [filing['form']], 'accessionNumber': [filing['accession_number']],
        'primaryDocument': [filing['primaryDocument']], 'reportDate': [filing['reportDate']], 'filingDate': [filing['filingDate']]}}}
    return company, record, facts, submissions


class SourceTests(unittest.TestCase):
    def test_fast_skill_prefilter_preserves_boundaries_unicode_and_alias_priority(self):
        job = {'title': 'HRİS Analyst', 'description_excerpt': 'Workday administration, then HRIS. Pythonic is not Python.', 'skills_mentioned': []}
        self.assertEqual(matching_skill_phrases(job, ['HRIS', 'Python']), {'HRIS': 'HRİS', 'Python': 'Python'})
        job.update(title='HRıS Analyst', description_excerpt='Pythonic HRISy')
        self.assertEqual(matching_skill_phrases(job, ['HRIS', 'Python']), {'HRIS': 'HRıS'})
        job.update(title='Workday administration', description_excerpt='HRIS')
        self.assertEqual(matching_skill_phrases(job, ['HRIS']), {'HRIS': 'HRIS'})

    def test_reconstructed_cash_flows_match_verified_quarters(self):
        ids = [c['company_id'] for c in json.loads((ROOT / 'data/companies.json').read_text())['companies']]
        for cid in ids:
            with self.subTest(company=cid):
                company, saved, facts, submissions = fixture_financials(cid)
                result = normalize_financials(facts, submissions, company, utcnow())
                for expected, actual in zip(saved['quarters'], result['quarters']):
                    self.assertEqual(expected['period_end'], actual['period_end'])
                    for metric in ('revenue', 'operating_cash_flow', 'research_and_development'):
                        self.assertEqual(expected[metric]['value'], actual[metric]['value'])
                self.assertAlmostEqual(saved['calculated_inputs']['operating_cash_flow_margin_pct'],
                                       result['calculated_inputs']['operating_cash_flow_margin_pct'], places=5)

    def test_latest_quarter_missing_is_not_silently_downgraded(self):
        company, _, facts, submissions = fixture_financials()
        submissions['filings']['recent']['reportDate'] = ['2026-09-30']
        with self.assertRaisesRegex(SourceError, 'latest filing'):
            normalize_financials(facts, submissions, company, utcnow())

    def test_cumulative_cash_flow_and_restatements(self):
        tag = 'NetCashProvidedByUsedInOperatingActivities'
        facts = {'facts': {'us-gaap': {tag: {'units': {'USD': [
            {'start': '2025-01-01', 'end': '2025-03-31', 'val': 10, 'filed': '2025-05-01', 'form': '10-Q'},
            {'start': '2025-01-01', 'end': '2025-03-31', 'val': 12, 'filed': '2026-05-01', 'form': '10-Q'},
            {'start': '2025-01-01', 'end': '2025-06-30', 'val': 32, 'filed': '2026-08-01', 'form': '10-Q'},
            {'start': '2025-01-01', 'end': '2025-09-30', 'val': 55, 'filed': '2025-11-01', 'form': '10-Q'},
            {'start': '2025-01-01', 'end': '2025-12-31', 'val': 81, 'filed': '2026-02-01', 'form': '10-K'}
        ]}}}}}
        values = quarter_values(facts, (tag,), '2025-12-31')
        self.assertEqual([values[(s, e)]['value'] for s, e in sorted(values)], [12, 20, 23, 26])
        self.assertEqual(sum(v['value'] for v in values.values()), 81)

    def test_job_location_evidence_and_deduplication(self):
        company, *_ = fixture_financials()
        job = {'id': 123, 'title': 'Backend Software Engineer', 'location': {'name': 'Remote'},
            'content': '<p>Python and SQL. Headquartered in San Francisco.</p>',
            'absolute_url': 'https://example.com/jobs/123'}
        rows = normalize_jobs({'jobs': [job]}, company, utcnow())
        self.assertEqual(len(rows), 1)
        self.assertFalse(match_location(rows[0], 'San Francisco'))
        job['metadata'] = [{'name': 'Job Posting Location', 'value': ['San Francisco, CA']}]
        rows = normalize_jobs({'jobs': [job, job]}, company, utcnow())
        self.assertEqual(len(rows), 1)
        self.assertEqual(match_location(rows[0], 'san francisco')[0]['field'], 'metadata.Job Posting Location')
        self.assertEqual(rows[0]['skills_mentioned'], ['Python', 'SQL'])
        self.assertNotIn('<p>', rows[0]['description_excerpt'])
        job['absolute_url'] = 'javascript:alert(1)'
        self.assertFalse(normalize_jobs({'jobs': [job]}, company, utcnow()))

    def test_hris_roles_and_related_programming_wording(self):
        company, *_ = fixture_financials()
        raw = {'id': 456, 'title': 'Workday Integration Developer', 'location': {'name': 'Newark, NJ'},
               'content': '<p>Build integrations for HR systems. Experience in software development.</p>',
               'absolute_url': 'https://example.com/jobs/456'}
        [job] = normalize_jobs({'jobs': [raw]}, company, utcnow())
        self.assertTrue(match_location(job, 'New Jersey'))
        self.assertEqual(matching_skill_phrases(job, ['HRIS', 'Programing', 'Python']),
                         {'HRIS': 'HR systems', 'Programing': 'software development'})

    def test_nationwide_location_covers_all_states_and_excludes_foreign_only_postings(self):
        for state in STATE_NAMES.values():
            with self.subTest(state=state):
                self.assertTrue(match_location({'location_evidence': [{'field': 'location', 'value': state}]}, 'United States'))
        for location in ('Toronto, ON, Canada', 'London, UK', 'Paris, France', 'Melbourne, Australia'):
            with self.subTest(location=location):
                self.assertFalse(match_location({'location_evidence': [{'field': 'location', 'value': location}]}, 'United States'))
        profile = validate_profile({'skills': ['HRIS', 'Python'],
                                    'locations': ['United States — all 50 states', 'New Jersey']})
        self.assertEqual(profile['locations'], ['United States'])

    def test_ifrs_quarter_uses_annual_revenue_alias_and_consolidated_context(self):
        document = b'''<html xmlns:ix="http://www.xbrl.org/2013/inlineXBRL"
                xmlns:xbrli="http://www.xbrl.org/2003/instance">
          <xbrli:context id="total"><xbrli:entity><xbrli:identifier>0001801198</xbrli:identifier></xbrli:entity>
            <xbrli:period><xbrli:startDate>2025-01-01</xbrli:startDate><xbrli:endDate>2025-09-30</xbrli:endDate></xbrli:period>
          </xbrli:context>
          <xbrli:context id="segment"><xbrli:entity><xbrli:identifier>0001801198</xbrli:identifier><xbrli:segment/></xbrli:entity>
            <xbrli:period><xbrli:startDate>2025-01-01</xbrli:startDate><xbrli:endDate>2025-09-30</xbrli:endDate></xbrli:period>
          </xbrli:context>
          <xbrli:unit id="usd"><xbrli:measure>iso4217:USD</xbrli:measure></xbrli:unit>
          <ix:nonFraction name="ifrs-full:Revenue" contextRef="segment" unitRef="usd" scale="6">100</ix:nonFraction>
          <ix:nonFraction name="ifrs-full:Revenue" contextRef="total" unitRef="usd" scale="6">720.5</ix:nonFraction>
        </html>'''
        facts = {'cik': 1801198, 'facts': {'ifrs-full': {'RevenueFromContractsWithCustomers': {'units': {'USD': [
            {'start': '2025-01-01', 'end': '2025-12-31', 'form': '20-F', 'val': 1028900000}
        ]}}}}}
        add_inline_ifrs_facts(facts, {'form': '6-K', 'filingDate': '2025-11-12', 'accession_number': 'fixture'}, document)
        revenue = quarter_values(facts, ('Revenue', 'RevenueFromContractsWithCustomers'), '2025-12-31',
                                 'ifrs-full', IFRS_FORMS, merge_tags=True)
        fourth_quarter = revenue['2025-10-01', '2025-12-31']
        self.assertEqual(fourth_quarter['value'], 308400000)
        self.assertEqual([fact['tag'] for fact in fourth_quarter['source_facts']],
                         ['RevenueFromContractsWithCustomers', 'Revenue'])

    def test_lever_uses_all_employer_locations_and_listed_requirements(self):
        company = {'company_id': 'fixture', 'job_board_provider': 'Lever',
                   'jobs_api_url': 'https://api.lever.co/v0/postings/fixture'}
        post = {'id': '5de3e795-ee09-41c4-99a7-a5a11229c9ee', 'text': 'Senior AI Engineer',
                'categories': {'location': 'New York', 'allLocations': ['New York', 'Jersey City, NJ']},
                'hostedUrl': 'https://jobs.lever.co/fixture/5de3e795-ee09-41c4-99a7-a5a11229c9ee',
                'description': '<p>Build software.</p>', 'lists': [{'content': '<li>Python experience</li>'}]}
        [job] = normalize_jobs(lever_jobs([post]), company, utcnow())
        self.assertTrue(match_location(job, 'New Jersey'))
        self.assertEqual(matching_skill_phrases(job, ['Python']), {'Python': 'Python'})
        self.assertEqual(job['application_url'], post['hostedUrl'])

    def test_arbitrary_urls_rejected_before_network(self):
        client = JsonHTTP({'data.sec.gov'}, 'fixture')
        for url in ('http://data.sec.gov/x', 'https://evil.example/x', 'https://data.sec.gov:8443/x'):
            with self.assertRaises(SourceError):
                client.request(url)


class FakeIBMTransport:
    def __init__(self):
        self.calls = []

    def request(self, url, **kwargs):
        self.calls.append((url, kwargs))
        if 'identity/token' in url:
            return {'access_token': 'test-token', 'expires_in': 3600}
        return {'choices': [{'finish_reason': 'stop', 'message': {'role': 'assistant', 'content': '{}'}}],
                'usage': {'prompt_tokens': 10, 'completion_tokens': 2}}


class TwoAgentIBMFixture(FakeIBMTransport):
    """Emulates the IBM transport only, never installed as an application fallback."""
    def request(self, url, **kwargs):
        if 'identity/token' in url:
            return super().request(url, **kwargs)
        self.calls.append((url, kwargs))
        wire = json.loads(kwargs['data'])
        messages = wire['messages']
        finance = messages[0]['content'].startswith('You are CompanyAssessmentAgent')
        evidence = [json.loads(m['content']) for m in messages if m['role'] == 'tool']
        tool, arguments, content = None, None, None
        if not evidence:
            if finance:
                tool = 'read_financial_evidence'
                arguments = {'company_ids': json.loads(messages[1]['content'].split(': ', 1)[1])}
            else:
                tool = 'search_jobs'
                arguments = {'skills': json.loads(messages[1]['content'])['skills']}
        elif finance:
            content = {'companies': [{'company_id': row['company_id'], 'evidence_fields': ['operating_cash_flow_margin_pct'],
                'financial_summary': 'Protocol fixture: R&D spending decreased.' if row['inputs']['research_and_development_change_yoy_pct'] < 0 else 'Protocol fixture: R&D spending increased.'}
                for row in evidence[-1]]}
        elif 'candidate_jobs' in evidence[-1]:
            tool = 'request_company_assessments'
            arguments = {'company_ids': evidence[-1]['company_ids']}
        else:
            content = {'shortlist': [{'job_id': jid, 'match_explanation': 'Protocol fixture: the posting mentions a requested skill.'}
                for jid in evidence[-1]['eligible_job_ids'][:evidence[-1]['required_shortlist_length']]]}
        message = {'role': 'assistant', 'content': json.dumps(content) if content is not None else ''}
        if tool:
            message['tool_calls'] = [{'id': 'fixture-' + str(len(self.calls)), 'type': 'function',
                'function': {'name': tool, 'arguments': json.dumps(arguments)}}]
        return {'choices': [{'finish_reason': 'tool_calls' if tool else 'stop', 'message': message}],
                'usage': {'prompt_tokens': 100, 'completion_tokens': 100}}


class IBMTests(unittest.TestCase):
    def test_two_agents_through_ibm_protocol_and_cached_repeat(self):
        with tempfile.TemporaryDirectory() as directory:
            engine = Engine(directory)
            jobs = json.loads((ROOT / 'data/jobs.json').read_text())['jobs']
            financials = {r['company_id']: r for r in json.loads((ROOT / 'data/financials.json').read_text())['companies']}
            for cid, record in financials.items():
                engine.store.save(cid, 'jobs', [j for j in jobs if j['company_id'] == cid])
                engine.store.save(cid, 'financials', record)
            transport = TwoAgentIBMFixture()
            engine.client_factory = lambda: WatsonxClient(engine.store, api_key='fixture', project_id='p', model='ibm/protocol-fixture',
                                                          enabled=True, http=transport)
            result = engine.search({'skills': ['Python', 'SQL'], 'freshness': 'use_cached'})
            self.assertEqual(len(result['shortlist']), 10)
            self.assertEqual(len(result['inference_usage']), 5)
            self.assertTrue(result['inference_executed'])
            self.assertEqual({e['agent'] for e in result['agent_trace']}, {'JobSearchAgent', 'CompanyAssessmentAgent'})
            self.assertTrue(all(j['matched_skills'] and j['company_assessment']['eligible'] for j in result['shortlist']))
            calls_before = len(transport.calls)
            again = engine.search({'skills': ['Python', 'SQL'], 'freshness': 'use_cached'})
            self.assertEqual(len(transport.calls), calls_before)
            self.assertTrue(again['assessment_cached'])
            self.assertFalse(again['inference_executed'])

    def test_auth_exchange_tool_wire_format_and_budget(self):
        with tempfile.TemporaryDirectory() as directory:
            transport, store = FakeIBMTransport(), Store(directory)
            client = WatsonxClient(store, api_key='fixture-only', project_id='project', model='ibm/test-only',
                                   enabled=True, http=transport, max_calls=2)
            messages = [{'role': 'system', 'content': 'JSON'}, {'role': 'assistant', 'content': '', 'tool_calls': [
                {'id': 'call-1', 'type': 'function', 'function': {'name': 'read', 'arguments': '{}'}}]},
                {'role': 'tool', 'tool_name': 'read', 'tool_call_id': 'call-1', 'content': '{}'}]
            tools = [{'type': 'function', 'function': {'name': 'read'}}]
            client.chat(messages, tools)
            wire = json.loads(transport.calls[-1][1]['data'])
            self.assertEqual(wire['tool_choice_option'], 'required')
            self.assertEqual(wire['messages'][-1]['tool_call_id'], 'call-1')
            self.assertNotIn('tool_name', wire['messages'][-1])
            self.assertEqual(transport.calls[-1][1]['headers']['Authorization'], 'Bearer test-token')
            client.chat([{'role': 'user', 'content': 'Return JSON'}], [])
            self.assertEqual(len([url for url, _ in transport.calls if 'identity/token' in url]), 1)
            self.assertEqual(json.loads(transport.calls[-1][1]['data'])['response_format'], {'type': 'json_object'})
            self.assertGreater(store.allowance()['reserved_token_units'], 0)
            with self.assertRaisesRegex(AgentError, 'seven-call'):
                client.chat([], [])

    def test_budget_and_disabled_gate_send_no_request(self):
        with tempfile.TemporaryDirectory() as directory:
            transport = FakeIBMTransport()
            client = WatsonxClient(Store(directory), api_key='fixture', project_id='p', model='test', enabled=False, http=transport)
            with self.assertRaisesRegex(AgentError, 'disabled'):
                client.chat([], [])
            client.enabled, client.monthly_budget = True, 1
            with self.assertRaisesRegex(AgentError, 'allowance'):
                client.chat([], [])
            self.assertFalse(transport.calls)


class StoreAndAPITests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.engine = Engine(self.directory.name)
        self.app = Application(self.engine, access_token='test-demo-token')

    def tearDown(self):
        self.directory.cleanup()

    def request(self, path, method='GET', payload=None, auth=True, browser=None):
        data = json.dumps(payload).encode() if payload is not None else b''
        environ = {'PATH_INFO': path, 'REQUEST_METHOD': method, 'wsgi.input': io.BytesIO(data),
            'CONTENT_LENGTH': str(len(data)), 'CONTENT_TYPE': 'application/json',
            'HTTP_AUTHORIZATION': 'Bearer test-demo-token' if auth else ''}
        environ.update(browser or {})
        statuses = []
        result = self.app(environ, lambda status, headers: statuses.append(status))
        return statuses[0], json.loads(b''.join(result))

    def test_auth_validation_health_and_disabled_inference(self):
        self.assertEqual(self.request('/api/health')[0], '200 OK')
        self.assertEqual(self.request('/api/search', 'POST', {'skills': ['Python']}, auth=False)[0], '401 Unauthorized')
        self.assertEqual(self.request('/api/search', 'POST', {'skills': 'Python'})[0], '400 Bad Request')
        self.assertEqual(self.request('/api/data/refresh', 'POST', {'url': 'https://evil.example'})[0], '400 Bad Request')
        status, body = self.request('/api/search', 'POST', {'skills': ['Python']})
        self.assertEqual(status, '503 Service Unavailable')
        self.assertFalse(body['simulated_result'])

    def test_failed_refresh_preserves_date_but_requires_cached_choice(self):
        old = (datetime.now(timezone.utc) - timedelta(days=2)).isoformat()
        self.engine.store.save('cloudflare', 'jobs', [{'job_id': 'fixture'}], old)
        self.engine.store.failed('cloudflare', 'jobs', 'fixture failure')
        record = self.engine.store.record('cloudflare', 'jobs')
        self.assertEqual(record['fetched_at'], old)
        self.assertEqual(self.engine.documents()[0]['jobs']['jobs'], [])
        self.assertEqual(self.engine.documents(use_cached=True)[0]['jobs']['jobs'], [{'job_id': 'fixture'}])

    def test_busy_and_unknown_source_inputs(self):
        with self.engine.store.operation_lock:
            self.assertEqual(self.request('/api/search', 'POST', {'skills': ['Python']})[0], '409 Conflict')
        self.assertEqual(self.request('/api/data/refresh', 'POST', {'company_ids': ['invented']})[0], '400 Bad Request')
        self.assertEqual(self.request('/api/data/refresh', 'POST', {'sources': ['linkedin']})[0], '400 Bad Request')

    def test_company_shortlist_browser_access_requires_the_loopback_origin_and_host(self):
        self.app = Application(self.engine, access_token='', local_browser_host='localhost:8080')
        browser = {'REMOTE_ADDR': '127.0.0.1', 'HTTP_HOST': 'localhost:8080',
                   'HTTP_ORIGIN': 'http://localhost:8080'}
        path = '/api/orchestrate/shortlist'
        profile = {'skills': ['Python'], 'freshness': 'use_cached'}
        self.assertEqual(self.request(path, 'POST', profile, auth=False, browser=browser)[0], '200 OK')
        for field, value in [('REMOTE_ADDR', '192.0.2.1'), ('HTTP_HOST', 'example.org'),
                             ('HTTP_ORIGIN', 'https://example.org'), ('HTTP_ORIGIN', '')]:
            with self.subTest(field=field, value=value):
                status, _ = self.request(path, 'POST', profile, auth=False, browser={**browser, field: value})
                self.assertNotEqual(status, '200 OK')

    def test_live_company_search_rechecks_recent_job_boards(self):
        company, _, facts, submissions = fixture_financials()
        financial = normalize_financials(facts, submissions, company, utcnow())
        financial['quarters'][-1]['period_end'] = datetime.now().date().isoformat()
        self.engine.companies = {company['company_id']: company}
        job = {'job_id': 'cloudflare:123', 'company_id': 'cloudflare', 'title': 'Senior Backend Engineer',
               'description_excerpt': 'Build services with Python', 'skills_mentioned': ['Python'],
               'san_francisco_location_evidence': [{'field': 'location.name', 'value': 'San Francisco'}],
               'location_raw': 'San Francisco', 'application_url': 'https://job-boards.greenhouse.io/example/jobs/123'}
        self.engine.store.save('cloudflare', 'jobs', [])
        self.engine.store.save('cloudflare', 'financials', financial)
        with patch.object(self.engine.sources, 'jobs', return_value=[job]) as fetch_jobs, \
                patch.object(self.engine.sources, 'financials') as fetch_financials:
            answer = self.engine.prepare_company_shortlist({'skills': ['Python'], 'freshness': 'live'})
        fetch_jobs.assert_called_once_with(company)
        fetch_financials.assert_not_called()
        self.assertEqual((answer['boards_checked'], answer['company_count'], answer['job_count']), (1, 1, 1))
        self.assertIn('Infinity Company Assessment', answer['prompt'])
        self.assertIn(job['application_url'], answer['prompt'])
        seattle_job = {**job, 'job_id': 'cloudflare:456', 'title': 'Senior Platform Engineer',
                       'location_raw': 'Seattle, WA', 'location_evidence': [{'field': 'location.name', 'value': 'Seattle, WA'}],
                       'application_url': 'https://job-boards.greenhouse.io/example/jobs/456'}
        self.engine.store.save('cloudflare', 'jobs', [job, seattle_job])
        answer = self.engine.prepare_company_shortlist({'skills': ['Python'], 'location': 'Seattle', 'freshness': 'use_cached'})
        self.assertEqual(answer['job_count'], 1)
        self.assertEqual(answer['source_links'][0]['openings'][0]['apply_url'], seattle_job['application_url'])
        self.assertIn('"location": "Seattle"', answer['prompt'])
        self.assertNotIn(job['application_url'], answer['prompt'])

    def test_jobs_only_board_returns_all_links_without_financial_review(self):
        company = self.engine.companies['foundationriskpartners']
        self.engine.companies = {company['company_id']: company}
        raw_jobs = [{'id': n, 'title': f'HRIS Analyst {n}', 'location': {'name': 'Bridgewater, NJ'},
                     'content': '<p>Administer the HR systems.</p>', 'absolute_url': f'https://example.com/jobs/{n}'}
                    for n in range(1, 5)]
        jobs = normalize_jobs({'jobs': raw_jobs}, company, utcnow())
        with patch.object(self.engine.sources, 'jobs', return_value=jobs), \
                patch.object(self.engine.sources, 'financials') as fetch_financials:
            result = self.engine.prepare_company_shortlist({'skills': ['HRIS'], 'location': 'New Jersey', 'freshness': 'live'})
        fetch_financials.assert_not_called()
        self.assertEqual((result['boards_checked'], result['job_count'], result['company_count']), (1, 4, 1))
        self.assertEqual([job['apply_url'] for job in result['source_links'][0]['openings']],
                         [job['absolute_url'] for job in raw_jobs])
        self.assertIsNone(result['source_links'][0]['sec_filing_url'])
        self.assertIsNone(result['prompt'])

    def test_two_location_live_search_ranks_multiple_jobs_from_half_year_employer(self):
        company = self.engine.companies['genscript']
        company['interim_financial_report']['period_end'] = datetime.now().date().isoformat()
        self.engine.companies = {'genscript': company}

        def discovered(keyword, location):
            city = 'Jersey City, New Jersey' if location == 'Jersey City, NJ' else 'Seattle, WA'
            return ([{'job_id': f'{keyword}:{city}', 'employer_name': 'GenScript', 'title': f'{keyword} Engineer',
                      'location_raw': city, 'location_evidence': [{'field': 'published location', 'value': city}],
                      'description_excerpt': '', 'skills_mentioned': [],
                      'application_url': f'https://example.com/{keyword}/{city.split(",")[0].replace(" ", "-")}'}], False)

        with patch.object(self.engine.sources, 'jobs', return_value=[]), \
                patch.object(self.engine.sources, 'discover_jobs', side_effect=discovered) as search:
            result = self.engine.prepare_company_shortlist({'skills': ['Python', 'HRIS'],
                'locations': ['Jersey City, NJ', 'Seattle'], 'freshness': 'live', 'discover': True})
        self.assertEqual(search.call_count, 4)
        self.assertEqual(result['discovery']['new_jobs'], 4)
        self.assertEqual(len(result['ranked_jobs']), 4)
        self.assertEqual({job['company'] for job in result['ranked_jobs']}, {'GenScript'})
        self.assertEqual({job['financial_score'] for job in result['ranked_jobs']}, {6.0})
        self.assertEqual({job['reporting_basis'] for job in result['ranked_jobs']}, {'Six-month report'})
        handoff = json.loads(result['prompt'].split('EMPLOYER LISTINGS AND SEC EVIDENCE\n')[1])[0]['financial_evidence']
        report = company['interim_financial_report']
        self.assertAlmostEqual(handoff['cash_flow_margin_pct'], round(100 * report['operating_cash_flow_usd'] / report['reported_revenue_usd'], 2))
        self.assertTrue(handoff['positive_period_operating_cash_flow'])
        self.assertNotIn('positive_cash_flow_quarters', handoff)
        self.assertTrue(handoff['eligible_for_shortlist'])
        ranked_handoff = json.loads(result['prompt'].split('TOP RANKED OPENINGS\n')[1].split('\n\nEMPLOYER LISTINGS')[0])
        self.assertEqual([job['rank'] for job in ranked_handoff], [1, 2, 3, 4])
        self.assertEqual([{key: value for key, value in job.items() if key != 'rank'} for job in ranked_handoff], result['ranked_jobs'])
        self.assertEqual({place for job in result['ranked_jobs'] for place in job['matched_locations']},
                         {'Jersey City, NJ', 'Seattle'})
        cached_profile = {'skills': ['Python', 'HRIS'], 'locations': ['Jersey City, NJ', 'Seattle'],
                          'freshness': 'use_cached', 'discover': True}
        reopened = Engine(self.directory.name)
        reopened.companies = self.engine.companies
        with patch.object(reopened.sources, 'discover_jobs') as discover_jobs, \
                patch.object(reopened.sources, 'issuer_directory') as issuers, \
                patch.object(reopened.sources, 'financials') as financials:
            cached = reopened.prepare_company_shortlist(cached_profile)
        discover_jobs.assert_not_called()
        issuers.assert_not_called()
        financials.assert_not_called()
        self.assertEqual(cached['ranked_jobs'], result['ranked_jobs'])
        self.assertTrue(cached['discovery']['cached'])
        self.assertFalse(cached['discovery']['stale'])
        self.assertIn('saved at', cached['prompt'])

        discovery_dates = {key: row['fetched_at'] for key, row in self.engine.store.records().items() if key[1] == 'discovery'}
        with patch.object(self.engine.sources, 'jobs') as recent_jobs, \
                patch.object(self.engine.sources, 'discover_jobs') as recent_discovery, \
                patch.object(self.engine.sources, 'issuer_directory') as recent_issuers:
            quick = self.engine.prepare_company_shortlist({**cached_profile, 'freshness': 'refresh_if_stale'})
        recent_jobs.assert_not_called()
        recent_discovery.assert_not_called()
        recent_issuers.assert_not_called()
        self.assertEqual(quick['ranked_jobs'], result['ranked_jobs'])
        self.assertIn('15-minute', quick['prompt'])
        self.assertEqual(discovery_dates, {key: row['fetched_at'] for key, row in self.engine.store.records().items() if key[1] == 'discovery'})

        with patch.object(self.engine.sources, 'jobs') as recent_jobs, \
                patch.object(self.engine.sources, 'discover_jobs', side_effect=discovered) as new_query:
            changed = self.engine.prepare_company_shortlist({**cached_profile, 'skills': ['Ruby'], 'freshness': 'refresh_if_stale'})
        recent_jobs.assert_not_called()
        self.assertEqual(new_query.call_count, 2)
        self.assertEqual(len(changed['ranked_jobs']), 2)
        self.assertFalse(changed['discovery'].get('cached', False))

        with patch.object(self.engine.sources, 'jobs', return_value=[]), \
                patch.object(self.engine.sources, 'discover_jobs', side_effect=SourceError('Unavailable')):
            failed = self.engine.prepare_company_shortlist({**cached_profile, 'freshness': 'live'})
        self.assertEqual(failed['discovery']['checked'], 0)
        retained = self.engine.prepare_company_shortlist(cached_profile)
        self.assertEqual(retained['ranked_jobs'], result['ranked_jobs'])

        other = reopened.prepare_company_shortlist({**cached_profile, 'locations': ['Boston']})
        self.assertIsNone(other['discovery'])
        self.assertEqual(other['job_count'], 0)

    def test_orchestrate_handoff_uses_only_available_evidence_without_inference(self):
        def no_ibm_client():
            self.fail('Preparing a chat message must not instantiate an IBM client')

        self.engine.client_factory = no_ibm_client
        company, _, facts, submissions = fixture_financials()
        financial = normalize_financials(facts, submissions, company, utcnow())
        # Keep the fixture within the reporting-age policy regardless of test date.
        financial['quarters'][-1]['period_end'] = datetime.now().date().isoformat()
        jobs = [{'job_id': cid + ':123', 'company_id': cid, 'title': 'Senior Backend Engineer',
                 'description_excerpt': 'Build services with Python', 'skills_mentioned': ['Python'],
                 'san_francisco_location_evidence': 'San Francisco', 'location_raw': 'San Francisco',
                 'application_url': 'https://job-boards.greenhouse.io/example/jobs/123',
                 'source_api_url': 'https://boards-api.greenhouse.io/v1/boards/example/jobs/123'}
                for cid in ('cloudflare', 'pinterest')]
        for job in jobs:
            self.engine.store.save(job['company_id'], 'jobs', [job])
        self.engine.store.save('cloudflare', 'financials', financial)
        self.engine.store.failed('cloudflare', 'financials', 'fixture failure after collection')
        path = '/api/orchestrate/prepare'
        profile = {'skills': ['Python'], 'focus': 'backend', 'experience_level': 'senior', 'freshness': 'use_cached'}
        self.assertEqual(self.request(path, 'POST', profile, auth=False)[0], '401 Unauthorized')
        status, body = self.request(path, 'POST', profile)
        self.assertEqual(status, '200 OK')
        self.assertEqual(body['matches_missing_evidence'], 1)
        self.assertEqual([r['job_id'] for r in body['candidates']], ['cloudflare:123'])
        candidate = body['candidates'][0]
        self.assertTrue(candidate['cached_fallback'])
        for expected in ('Python', 'positive in ', 'cash flow margin', 'YoY revenue growth', 'YoY R&D growth',
                         'stability score', financial['latest_periodic_filing']['filing_url'], jobs[0]['application_url']):
            self.assertIn(expected, candidate['prompt'])
        self.assertNotIn('test-demo-token', candidate['prompt'])

    @unittest.skipUnless(importlib.util.find_spec('cryptography'), 'Optional Orchestrate embed dependency')
    def test_embed_requires_operator_access_and_signs_short_lived_tokens(self):
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding, rsa

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        private_path = Path(self.directory.name) / 'test-private.pem'
        private_path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                                  serialization.NoEncryption()))
        config = {'hostURL': 'https://eu-de.watson-orchestrate.cloud.ibm.com', 'crn': 'test-crn',
                  'orchestrationID': 'test-instance', 'chatOptions': {'agentId': 'lead', 'agentEnvironmentId': 'live'}}
        path = '/api/orchestrate/embed-token'
        with patch.dict(os.environ, {'ORCHESTRATE_EMBED_CONFIG': json.dumps(config),
                                     'ORCHESTRATE_EMBED_PRIVATE_KEY_FILE': str(private_path)}):
            self.assertEqual(self.request(path, 'POST', auth=False)[0], '401 Unauthorized')
            self.assertEqual(self.request(path, 'GET')[0], '405 Method Not Allowed')
            status, session = self.request(path, 'POST')
            self.assertEqual(status, '200 OK')
            self.assertEqual(session['widget']['chatOptions'], config['chatOptions'])
            self.assertNotIn(str(private_path), json.dumps(session))
            header, payload, signature = session['token'].split('.')
            decode = lambda value: base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))
            self.assertEqual(json.loads(decode(header))['alg'], 'RS256')
            key.public_key().verify(decode(signature), f'{header}.{payload}'.encode(), padding.PKCS1v15(), hashes.SHA256())
            claims = json.loads(decode(payload))
            self.assertEqual(set(claims), {'sub', 'iat', 'exp'})
            self.assertEqual(claims['exp'], session['expires_at'])
            self.assertEqual(claims['exp'] - claims['iat'], 600)

    def test_missing_financials_are_unassessed(self):
        docs = {'companies': self.engine.companies_doc, 'jobs': {'jobs': []}, 'financials': {'companies': []}}
        client = type('UnusedClient', (), {'model': 'unused'})()
        app = LiveJobSystem(client=client, documents=docs, cache_dir=Path(self.directory.name)/'agents')
        result = app.assess_companies(['cloudflare'])['companies'][0]
        self.assertIsNone(result['score'])
        self.assertFalse(result['eligible'])

    def test_profile_city(self):
        self.assertEqual(validate_profile({'skills': ['Python']})['location'], 'San Francisco')
        self.assertEqual(validate_profile({'skills': ['Python'], 'location': ' New  York '})['location'], 'New York')
        for location in ('', '   ', None, ['Seattle'], 'x' * 81):
            with self.subTest(location=location), self.assertRaises(ValueError):
                validate_profile({'skills': ['Python'], 'location': location})


if __name__ == '__main__':
    unittest.main()
