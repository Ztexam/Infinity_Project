"""Protocol fixtures are used only in tests, never as runtime AI fallbacks."""
import json
import unittest

from poc.backend import AgentError, JobSystem, OllamaClient, function_tool, run_agent
from poc.scoring import score_company


def response(content="", tool=None, arguments=None):
    message = {"role": "assistant", "content": content}
    if tool:
        message["tool_calls"] = [{"function": {"name": tool, "arguments": arguments or {}}}]
    return {"message": message, "model": "protocol-test-fixture"}


class ScriptedClient:
    model = "protocol-test-fixture"

    def __init__(self, fn):
        self.fn = fn
        self.calls = []

    def chat(self, messages, tools, format_schema=None):
        self.calls.append(messages[0]["content"])
        return self.fn(messages, tools)


class ScoringTests(unittest.TestCase):
    def inputs(self, cash=12, growth=6, rd=-2, nonpositive=1):
        return {"operating_cash_flow_margin_pct": cash, "revenue_growth_yoy_pct": growth,
                "research_and_development_change_yoy_pct": rd,
                "nonpositive_operating_cash_flow_quarters": nonpositive,
                "latest_four_totals_usd": {"operating_cash_flow": 120}}

    def test_worked_example(self):
        result = score_company(self.inputs())
        self.assertEqual(result["score"], 7.3)
        self.assertTrue(result["eligible"])

    def test_threshold_strictly_above_five(self):
        result = score_company(self.inputs(cash=-1, growth=20, rd=0, nonpositive=0))
        self.assertEqual(result["score"], 5)
        self.assertFalse(result["eligible"])

    def test_cash_burn_cannot_pass_on_other_factors(self):
        inputs = self.inputs(cash=20, growth=20, rd=0, nonpositive=0)
        inputs["latest_four_totals_usd"]["operating_cash_flow"] = -1
        self.assertFalse(score_company(inputs)["eligible"])

    def test_rd_boundary_and_missing_data(self):
        self.assertEqual(score_company(self.inputs(rd=-5))["rd_score"], 7)
        self.assertEqual(score_company(self.inputs(rd=-15))["rd_score"], 4)
        self.assertIsNone(score_company({})["score"])


class AgentTests(unittest.TestCase):
    def test_unknown_tool_rejected(self):
        client = ScriptedClient(lambda m, t: response(tool="invented_tool"))
        with self.assertRaisesRegex(AgentError, "Unknown tool"):
            run_agent("test", client, "system", "user", [], {}, lambda o, s: o, [])

    def test_model_loop_is_bounded(self):
        client = ScriptedClient(lambda m, t: response(content="not JSON"))
        with self.assertRaisesRegex(AgentError, "round limit"):
            run_agent("test", client, "system", "user", [], {}, lambda o, s: o, [], max_rounds=2)
        self.assertEqual(len(client.calls), 2)

    def test_two_separate_agent_contexts_and_handoff(self):
        names = []
        bad_explanation_once = [True]

        def scripted(messages, tools):
            finance = messages[0]["content"].startswith("You are CompanyAssessmentAgent")
            names.append("finance" if finance else "jobs")
            tool_messages = [m for m in messages if m["role"] == "tool"]
            if finance:
                if not tool_messages:
                    ids = json.loads(messages[1]["content"].split(": ", 1)[1])
                    return response(tool="read_financial_evidence", arguments={"company_ids": ids})
                rows = json.loads(tool_messages[-1]["content"])
                return response(json.dumps({"companies": [{"company_id": r["company_id"],
                    "financial_summary": "Protocol fixture: R&D spending decreased." if r["inputs"]["research_and_development_change_yoy_pct"] < 0 else "Protocol fixture: R&D spending increased.",
                    "evidence_fields": ["operating_cash_flow_margin_pct"]} for r in rows]}))
            if not tool_messages:
                skills = json.loads(messages[1]["content"])["skills"]
                return response(tool="search_jobs", arguments={"skills": skills})
            last = json.loads(tool_messages[-1]["content"])
            if "candidate_jobs" in last:
                return response(tool="request_company_assessments", arguments={"company_ids": last["company_ids"]})
            ids = last["eligible_job_ids"][:last["required_shortlist_length"]]
            rows = [{"job_id": jid, "match_explanation": "Protocol fixture."} for jid in ids]
            if bad_explanation_once[0]:
                rows[0]["match_explanation"] = "No explicit mention of Python."
                bad_explanation_once[0] = False
            return response(json.dumps({"shortlist": rows}))

        app = JobSystem(client=ScriptedClient(scripted), use_cache=False)
        result = app.run(["Python", "SQL"])
        self.assertEqual(len(result["shortlist"]), 10)
        self.assertIn("finance", names)
        self.assertIn("jobs", names)
        self.assertTrue(all(r["company_assessment"]["score"] > 5 for r in result["shortlist"]))
        self.assertTrue(all(r["application_url"].startswith("https://") for r in result["shortlist"]))
        # Each model conversation has exactly its own system instruction/history.
        self.assertTrue(any(e.get("tool") == "request_company_assessments" for e in result["agent_trace"]))
        self.assertTrue(any(e["event"] == "output_validation_error" for e in result["agent_trace"]))
        self.assertFalse(any("No explicit mention" in r["match_explanation"] for r in result["shortlist"]))

    def test_financial_tool_rejects_unknown_company(self):
        app = JobSystem(use_cache=False)
        with self.assertRaisesRegex(ValueError, "Unknown company"):
            app.financial_evidence(["invented-company"])


if __name__ == "__main__":
    unittest.main()
