"""Encrypted migration, archive boundaries and real signing; no fake AI responses."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from deploy.package_portable import build_bundle
from portable import encrypted_connection, restore_connection, validate_connection, configure


@unittest.skipUnless(importlib.util.find_spec('cryptography'), 'Requires the portable cryptography dependency')
class PortableConnectionTests(unittest.TestCase):
    def setUp(self):
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / 'original'
        self.source.mkdir()
        self.password = 'fixture-transfer-passphrase-123'
        self.pem = rsa.generate_private_key(public_exponent=65537, key_size=2048).private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
        self.widget = {'hostURL': 'https://eu-de.watson-orchestrate.cloud.ibm.com', 'crn': 'test-crn',
                       'orchestrationID': 'test-instance', 'chatOptions': {'agentId': 'test-lead', 'agentEnvironmentId': 'live'},
                       'arbitrary_script_option': 'must not transfer'}
        (self.source / 'client-private.pem').write_bytes(self.pem)
        (self.source / 'live-widget.json').write_text(json.dumps(self.widget))
        (self.source / 'portable-settings.json').write_text(json.dumps({'sec_user_agent': 'TestProject project@example.org'}))

    def tearDown(self):
        self.temp.cleanup()

    def test_round_trip_is_encrypted_and_signs_without_an_api_key(self):
        raw = encrypted_connection(self.source, self.password)
        self.assertNotIn(self.pem, raw)
        self.assertNotIn(self.password.encode(), raw)
        backup = self.root / 'connection.enc'
        backup.write_bytes(raw)
        target = self.root / 'moved project connection'
        restore_connection(backup, target, self.password)
        self.assertEqual((target / 'client-private.pem').read_bytes(), self.pem)
        self.assertNotIn('arbitrary_script_option', json.loads((target / 'live-widget.json').read_text()))
        with patch.dict(os.environ, {'IBM_CLOUD_API_KEY': ''}):
            configure(target)
            from service.orchestrate_embed import create_session
            session = create_session()
            self.assertEqual(session['widget']['chatOptions']['agentId'], 'test-lead')
            self.assertEqual(len(session['token'].split('.')), 3)
            self.assertFalse(os.getenv('IBM_CLOUD_API_KEY'))
            self.assertFalse(os.getenv('INFERENCE_ENABLED') == 'true')

    def test_wrong_password_and_tampering_do_not_write_keys(self):
        backup = self.root / 'connection.enc'
        backup.write_bytes(encrypted_connection(self.source, self.password))
        target = self.root / 'new'
        with self.assertRaises(ValueError):
            restore_connection(backup, target, 'wrong-password')
        self.assertFalse(target.exists())
        encoded = json.loads(backup.read_text())
        encoded['ciphertext'] = encoded['ciphertext'][:-8] + 'AAAAAAAA'
        backup.write_text(json.dumps(encoded))
        with self.assertRaises(ValueError):
            restore_connection(backup, target, self.password)
        self.assertFalse(target.exists())

    def test_reimport_and_non_ibm_hosts_are_rejected(self):
        backup = self.root / 'connection.enc'
        backup.write_bytes(encrypted_connection(self.source, self.password))
        with self.assertRaises(ValueError):
            restore_connection(backup, self.source, self.password)
        self.assertEqual((self.source / 'client-private.pem').read_bytes(), self.pem)
        with self.assertRaises(ValueError):
            validate_connection({**self.widget, 'hostURL': 'https://example.com'}, self.pem)


class PortableArchiveTests(unittest.TestCase):
    def test_source_archive_contains_runtime_assets_without_local_credentials(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'source.zip'
            build_bundle(path)
            with zipfile.ZipFile(path) as archive:
                names = archive.namelist()
                for required in ('frontend/live.html', 'service/additional_employers.json', 'portable.py', 'start.py', 'PORTABLE_SETUP.md'):
                    self.assertIn('Infinity_Project/' + required, names)
                self.assertNotIn('Infinity_Project/connection/ibm-connection.enc', names)
                self.assertFalse(any(name.endswith(('.pem', '.dpapi', '.env')) or '/runtime_cache/' in name or '/.portable-venv/' in name for name in names))
                manifest = json.loads(archive.read('Infinity_Project/MANIFEST.json'))
                self.assertFalse(manifest['encrypted_connection_included'])
                self.assertEqual(archive.getinfo('Infinity_Project/start.sh').external_attr >> 16 & 0o111, 0o111)
