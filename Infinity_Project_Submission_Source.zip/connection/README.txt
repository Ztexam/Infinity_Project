The personal portable ZIP contains ibm-connection.enc here.
It is an encrypted backup of the existing IBM widget configuration and signing key.
Unlock it once on the new machine using the separate transfer password.
Keep both the encrypted backup and password private. No IBM API key is needed.
The code-only ZIP deliberately has no connection backup.
See PORTABLE_SETUP.md for setup, server access, IBM origin settings and rollback.
