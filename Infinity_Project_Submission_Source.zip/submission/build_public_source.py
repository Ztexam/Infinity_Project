"""Stage only reviewed public source; never copy an entire working directory."""
import hashlib
import json
import re
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from deploy.package_portable import portable_files


def build():
    target = ROOT / 'dist' / 'public-submission-v1'
    target.mkdir(parents=True, exist_ok=True)
    names = {p.relative_to(ROOT).as_posix(): p for p in portable_files()}
    for name in ['.gitignore', 'docs/qa-agents-nationwide-after-deploy-2026-11-19.json',
                 'submission/problem_solution.txt', 'submission/technology_statement.txt',
                 'submission/READINESS.txt', 'submission/video_plan.txt', 'submission/DATA_SOURCES.txt',
                 'submission/build_public_source.py']:
        names[name] = ROOT / name
    for p in (ROOT / 'bob_sessions').glob('*.jpg'):
        names[p.relative_to(ROOT).as_posix()] = p
    for name, source in names.items():
        destination = target / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        if name == 'data/jobs.json':
            data = json.loads(source.read_text(encoding='utf-8'))
            for job in data['jobs']:
                job['description_excerpt'] = ''
            data['public_copy_note'] = 'Original description excerpts omitted from public distribution; factual metadata retained. Original local snapshot is unchanged.'
            destination.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
        else:
            shutil.copyfile(source, destination)
    shutil.copyfile(ROOT / 'submission/PUBLIC_README.md', target / 'README.md')
    bob_readme = target / 'bob_sessions/README.md'
    bob_readme.write_text('# IBM Bob task evidence\n\n'
        'The November 10 completed task built the initial live shortlist frontend and GET /live route. '
        'The task was reopened on November 20 in the ibm-skillsbuild-ell account without starting a new AI task. '
        'The expanded task-header screenshot includes its task ID/workspace and the visible 1.07 usage at the bottom. '
        'The earlier completed-task screenshot is also retained. No new Bob inference was used to recover this evidence.\n\n'
        '![Expanded task header and usage](2026-11-20-task-summary.jpg)\n\n'
        '![Original completed task](2026-11-10-live-shortlist.jpg)\n', encoding='utf-8')
    files = sorted(p for p in target.rglob('*') if p.is_file())
    allowed = set(names) | {'README.md', 'bob_sessions/README.md'}
    assert all(p.relative_to(target).as_posix() in allowed for p in files), 'Unexpected file in public staging directory'
    for p in files:
        relative = p.relative_to(target).as_posix()
        assert not any(x in relative.split('/') for x in ['.runtime', 'runtime_cache', '.portable-venv', '.git'])
        assert not p.suffix.lower() in {'.pem', '.enc', '.dpapi'}, relative
        if p.suffix.lower() in {'.py', '.txt', '.md', '.html', '.json', '.yaml'}:
            text = p.read_text(encoding='utf-8')
            assert not re.search(r'^-----BEGIN (?:RSA )?PRIVATE KEY-----\s*$', text, re.M), relative
            assert not re.search(r'[\w.+-]+@gmail\.com', text), relative
    archive = ROOT / 'dist/Infinity_Project_Submission_Source.zip'
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for p in files:
            bundle.write(p, p.relative_to(target).as_posix())
    manifest = {p.relative_to(target).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (ROOT / 'dist/public-source-audit.json').write_text(json.dumps({'files': manifest,
        'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'private_connection_included': False, 'job_descriptions_omitted': True}, indent=2) + '\n', encoding='utf-8')
    print(f'Public source: {len(files)} files; {archive.stat().st_size} bytes')
    print(target)


if __name__ == '__main__':
    build()
