"""Portable bootstrap: Python 3.11+, a private venv, and no PowerShell dependency."""
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import venv

ROOT = Path(__file__).resolve().parent


def main():
    if sys.version_info < (3, 11):
        raise SystemExit('Install Python 3.11 or newer from python.org, then launch again.')
    environment = ROOT / '.portable-venv'
    executable = environment / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    requirements = ROOT / 'requirements-portable.txt'
    digest = hashlib.sha256(requirements.read_bytes()).hexdigest()
    marker = environment / '.shortlist-requirements'
    if not executable.is_file():
        print('First launch: creating the app Python environment...', flush=True)
        venv.EnvBuilder(with_pip=True).create(environment)
    valid = marker.is_file() and marker.read_text().strip() == digest
    if valid:
        valid = subprocess.run([str(executable), '-c', 'import cryptography, waitress'],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    if not valid:
        print('Installing the two app dependencies from PyPI. Internet is needed on first launch.', flush=True)
        subprocess.run([str(executable), '-m', 'pip', 'install', '--disable-pip-version-check',
                        '--only-binary=:all:', '-r', str(requirements)], check=True)
        marker.write_text(digest)
    raise SystemExit(subprocess.call([str(executable), '-m', 'portable', *sys.argv[1:]], cwd=ROOT))


if __name__ == '__main__':
    try:
        main()
    except (OSError, subprocess.SubprocessError) as exc:
        print('Setup could not finish. Check Python, Internet access and the messages above.\n' + type(exc).__name__)
        raise SystemExit(1)
