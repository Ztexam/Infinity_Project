# Infinity Job Shortlist

A working IBM SkillsBuild proof of concept that connects job matching with explainable employer financial evidence.

Candidates enter keywords such as **HRIS** and **Python**, then select a city, state, or **United States — all 50 states**. Python collects and prepares source evidence. Two deployed IBM watsonx Orchestrate agents collaborate to explain up to ten eligible openings, with financial scores and employer/report links.

## How the two agents work

1. **Infinity Job Shortlist** receives matching listings and sends complete company financial evidence to its collaborator.
2. **Infinity Company Assessment** explains the supplied cash flow, revenue growth, R&D, reporting basis, score, and eligibility.
3. The shortlist agent returns up to ten distinct job links, retaining multiple openings at one employer when appropriate.

Python calculates the provisional score: **50% cash flow, 30% revenue growth, 20% R&D**. A company must score **strictly above 5/10** and have positive operating cash flow for the reported period. Comparable six-month reports are accepted. Missing evidence means unassessed, not financially unsound. Scores are research aids, not guarantees of employer stability or employment.

## Run locally

Install **Python 3.11 or newer**, download this repository as a ZIP, and extract it to a writable folder.

- **Windows:** double-click `Start Shortlist.cmd`.
- **macOS/Linux:** run `sh start.sh` from the extracted folder.
- Open **http://localhost:8080/live**. Keep the launcher running while using the app.

The launcher creates its own Python environment and installs pinned dependencies on first use. Windows relocation was tested. Native macOS/Linux and Docker execution have not yet been verified.

### Connecting to the real IBM agents

This public repository contains **no IBM credentials or private signing keys**. The deployed agents belong to a private IBM lab instance. A fresh installation requires an authorized encrypted connection transfer from the instance owner, or a separately configured instance and registered signing keys/origin. The setup wizard prompts for the connection backup and its separately provided password. Do not place those files in this repository.

Once configured, short-lived signed chat tokens let the app use embedded IBM chat **without entering an IBM API key in the browser**. This still depends on authorized instance access, service availability, and its usage allowance. It does not provide anonymous access or guarantee free inference. The registered development origin is `http://localhost:8080`.

See [portable setup](PORTABLE_SETUP.md) and [connection instructions](connection/README.txt). The local frontend/Python service and the two IBM-hosted agents are separate components. The entire Python backend has not been deployed to IBM Cloud.

## Data and performance

The collector supports **72 employer boards**, Greenhouse/Lever feeds, keyword/location discovery, SEC financial facts and filings, and verified six-month report evidence. It uses bounded concurrent requests, source throttling, deduplication, provenance, 15-minute job/discovery caches, and a 24-hour financial cache. The UI distinguishes refreshed, cached, and failed sources. A cold search can take substantially longer than a warm one; IBM inference adds separate latency.

The historical `data/` files are dated development snapshots, not current search results. This public copy omits job-description excerpts; the working source snapshots in the development workspace are preserved. Employer titles, source links, skill tags, and financial facts remain for reproducible checks. See [source inventory](submission/DATA_SOURCES.txt). Free public access is not an unrestricted content license; operators must follow provider/employer terms and avoid republishing descriptions without permission.

## IBM Bob contribution

IBM Bob IDE implemented the initial live frontend in `frontend/live.html` and the `GET /live` API route in `service/app.py`. The completed November 10 task and its expanded task header were recovered in the `ibm-skillsbuild-ell` account. Its visible usage is **1.07 Bobcoins**. Subsequent application enhancements and IBM deployment work were performed separately.

See [Bob task evidence](bob_sessions/README.md). Later QA records that say “no Bob call” describe those later operations, not the entire project's development history.

## Validation

The November 19 live nationwide HRIS/Python collection checked all 72 boards and found 856 matching openings across 96 employers. After correcting the handoff, the live agent test returned ten application links and ten report links in the expected order and accepted GenScript's six-month evidence. These are dated observations, not current vacancy or performance promises.

- [Agent instructions and changes](docs/agent-behavior-change-2026-11-19.json)
- [Live agent QA](docs/qa-agents-nationwide-after-deploy-2026-11-19.json)
- [Moved Windows installation QA](docs/qa-portable-connection-2026-11-19.json)
- [Measured performance](docs/qa-portable-performance-2026-11-19.json)

Local checks, which do not call IBM:

```sh
python -m unittest discover -s tests -v
python -m poc check
```

Run these with the launcher's Python environment after dependencies are installed. Protocol fixtures in unit tests are not evidence of actual AI execution; the separate dated live QA records provide that evidence.

## Submission materials and limits

The written statements and current readiness checklist are in `submission/`. The existing Ava video is an animated explainer; a revised on-screen demonstration is required before final lab submission. The official AI submission advisor precheck has not yet run.

No employee reviews are collected, no job applications are submitted, and results can be fewer than ten when fewer openings have sufficient evidence. The deployed agents use GPT-OSS 120B via Groq within watsonx Orchestrate; this project does not claim Granite use. Data feeds, reporting coverage, model output, and the time-limited lab instance constrain the POC.
