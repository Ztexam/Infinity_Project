"""Cross-platform signed IBM embed launcher and encrypted connection transfer."""
import argparse
import base64
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import threading
import urllib.error
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent
BACKUP_FORMAT = 'infinity-connection-v1'
BACKUP_AAD = BACKUP_FORMAT.encode()
PBKDF_ITERATIONS = 600000


def config_directory():
    if os.getenv('SHORTLIST_CONFIG_DIR'):
        return Path(os.environ['SHORTLIST_CONFIG_DIR']).expanduser().resolve()
    if os.name == 'nt':
        base = Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local'))
    elif sys.platform == 'darwin':
        base = Path.home() / 'Library/Application Support'
    else:
        base = Path(os.environ.get('XDG_CONFIG_HOME', Path.home() / '.config'))
    return base / 'InfinityProject/orchestrate-embed'


def protect(path):
    """Restrict newly written connection files to the current OS user."""
    path = Path(path)
    if os.name == 'nt':
        system_directory = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32'
        result = subprocess.run([str(system_directory / 'whoami.exe'), '/user', '/fo', 'csv', '/nh'], check=True,
                                capture_output=True, text=True)
        match = re.search(r'S-1-\d+(?:-\d+)+', result.stdout)
        if not match:
            raise ValueError('Could not identify the Windows user for file protection')
        grant = '*' + match.group() + (':(OI)(CI)F' if path.is_dir() else ':F')
        subprocess.run([str(system_directory / 'icacls.exe'), str(path), '/inheritance:r', '/grant:r', grant],
                       check=True, capture_output=True)
    else:
        path.chmod(0o700 if path.is_dir() else 0o600)


def private_write(path, data):
    path = Path(path)
    if not path.parent.exists():
        path.parent.mkdir(parents=True, mode=0o700)
        protect(path.parent)
    descriptor = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'wb') as target:
        target.write(data)
    protect(path)


def validate_connection(config, key_bytes):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    if not isinstance(config, dict) or not re.fullmatch(
            r'https://[a-z0-9-]+\.watson-orchestrate\.cloud\.ibm\.com', config.get('hostURL', '')):
        raise ValueError('The connection must use an IBM Cloud Orchestrate host')
    chat = config.get('chatOptions', {})
    for value in (config.get('crn'), config.get('orchestrationID'), chat.get('agentId'), chat.get('agentEnvironmentId')):
        if not isinstance(value, str) or not value:
            raise ValueError('The Live widget configuration is incomplete')
    key = serialization.load_pem_private_key(key_bytes, password=None)
    if not isinstance(key, rsa.RSAPrivateKey) or key.key_size < 2048:
        raise ValueError('An RSA private key of at least 2048 bits is required')
    # Keep only IBM's public widget fields; arbitrary script options are not transferable.
    widget = {k: config[k] for k in ('hostURL', 'crn', 'orchestrationID')}
    widget['deploymentPlatform'] = 'ibmcloud'
    widget['chatOptions'] = {k: chat[k] for k in ('agentId', 'agentEnvironmentId')}
    return widget


def encryption_key(password, salt):
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    return PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt,
                      iterations=PBKDF_ITERATIONS).derive(password.encode('utf-8'))


def encrypted_connection(directory, password):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    if len(password) < 12:
        raise ValueError('Use a transfer password of at least twelve characters')
    directory = Path(directory)
    key_bytes = (directory / 'client-private.pem').read_bytes()
    widget = validate_connection(json.loads((directory / 'live-widget.json').read_text(encoding='utf-8')), key_bytes)
    settings_path = directory / 'portable-settings.json'
    settings = json.loads(settings_path.read_text(encoding='utf-8')) if settings_path.is_file() else {}
    contact = os.getenv('SEC_USER_AGENT') or settings.get('sec_user_agent', '')
    if not re.search(r'[^\s@]+@[^\s@]+\.[^\s@]+', contact):
        raise ValueError('Configure SEC_USER_AGENT with your project contact email before exporting')
    payload = json.dumps({'widget': widget, 'private_key_pem': key_bytes.decode('ascii'),
                          'sec_user_agent': contact}).encode()
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    encrypted = AESGCM(encryption_key(password, salt)).encrypt(nonce, payload, BACKUP_AAD)
    encode = lambda value: base64.b64encode(value).decode('ascii')
    return json.dumps({'format': BACKUP_FORMAT, 'salt': encode(salt), 'nonce': encode(nonce),
                       'ciphertext': encode(encrypted)}).encode()


def restore_connection(backup, directory, password):
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    raw = Path(backup).read_bytes()
    if len(raw) > 100000:
        raise ValueError('Connection backup is unexpectedly large')
    bundle = json.loads(raw)
    if bundle.get('format') != BACKUP_FORMAT:
        raise ValueError('Unsupported connection backup')
    decode = lambda name: base64.b64decode(bundle[name], validate=True)
    try:
        payload = json.loads(AESGCM(encryption_key(password, decode('salt'))).decrypt(
            decode('nonce'), decode('ciphertext'), BACKUP_AAD))
    except InvalidTag:
        raise ValueError('Transfer password is incorrect or the backup was modified') from None
    key_bytes = payload['private_key_pem'].encode('ascii')
    widget = validate_connection(payload['widget'], key_bytes)
    directory = Path(directory)
    if any((directory / name).exists() for name in ('client-private.pem', 'live-widget.json')):
        raise ValueError('A connection already exists here. Use a new --config-dir to avoid overwriting it.')
    private_write(directory / 'client-private.pem', key_bytes)
    private_write(directory / 'live-widget.json', json.dumps(widget, indent=2).encode())
    private_write(directory / 'portable-settings.json', json.dumps({'sec_user_agent': payload['sec_user_agent']}).encode())


def ensure_connection(directory, backup=None):
    directory = Path(directory)
    if (directory / 'client-private.pem').is_file() and (directory / 'live-widget.json').is_file():
        return
    backup = Path(backup) if backup else ROOT / 'connection/ibm-connection.enc'
    if not backup.is_file():
        raise ValueError('No IBM connection. Import an encrypted connection backup; see PORTABLE_SETUP.md.')
    print('One-time setup: unlock the encrypted IBM connection. No IBM API key is needed.')
    restore_connection(backup, directory, getpass.getpass('Transfer password (hidden): '))


def configure(directory):
    directory = Path(directory)
    key_file = directory / 'client-private.pem'
    widget = validate_connection(json.loads((directory / 'live-widget.json').read_text(encoding='utf-8')), key_file.read_bytes())
    os.environ['ORCHESTRATE_EMBED_CONFIG'] = json.dumps(widget)
    os.environ['ORCHESTRATE_EMBED_PRIVATE_KEY_FILE'] = str(key_file.resolve())
    os.environ['INFERENCE_ENABLED'] = 'false'
    settings = directory / 'portable-settings.json'
    contact = json.loads(settings.read_text(encoding='utf-8')).get('sec_user_agent') if settings.is_file() else None
    os.environ.setdefault('SEC_USER_AGENT', contact or '')
    if not re.search(r'[^\s@]+@[^\s@]+\.[^\s@]+', os.environ['SEC_USER_AGENT']):
        raise ValueError('Set SEC_USER_AGENT with a project contact email for SEC requests; see PORTABLE_SETUP.md')
    token_file = directory / 'app-access-token.txt'
    if not token_file.is_file():
        private_write(token_file, secrets.token_urlsafe(32).encode('ascii'))
    os.environ['APP_ACCESS_TOKEN'] = token_file.read_text(encoding='ascii').strip()
    if not os.environ['APP_ACCESS_TOKEN']:
        raise ValueError('The app access token file is empty')
    os.environ.setdefault('CACHE_DIR', str(ROOT / 'runtime_cache/ibm'))
    return widget


def existing_local_server(port):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(f'http://localhost:{port}/api/health', timeout=2) as response:
            health = json.load(response)
        return health.get('service') == 'shortlist-ibm' and health.get('local_browser_access') is True
    except (OSError, ValueError):
        return False


def run(args, directory):
    from waitress import create_server
    from service.app import Application
    ensure_connection(directory)
    configure(directory)
    if not 1 <= args.port <= 65535:
        raise ValueError('Choose a port between 1 and 65535')
    host = args.host or ('0.0.0.0' if args.server else '127.0.0.1')
    if host not in ('127.0.0.1', 'localhost') and not args.server:
        raise ValueError('Use --server for network binding; server requests require the app access token')
    url = f'http://localhost:{args.port}/live'
    if not args.server and existing_local_server(args.port):
        print('Shortlist is already running: ' + url)
        if not args.no_browser:
            webbrowser.open(url)
        return
    application = Application(local_browser_host=None if args.server else f'localhost:{args.port}')
    server = create_server(application, host=host, port=args.port, threads=4, channel_timeout=900,
                           clear_untrusted_proxy_headers=True)
    print('Shortlist ready: ' + url, flush=True)
    if args.port != 8080:
        print('IBM must allow this exact origin/port before embedded agents work here.', flush=True)
    if args.server:
        print('Server mode requires the app access token saved in: ' + str(directory / 'app-access-token.txt'), flush=True)
        print('Use HTTPS and register your exact origin in IBM for a remote browser. See PORTABLE_SETUP.md.', flush=True)
    elif not args.no_browser:
        threading.Timer(.3, lambda: webbrowser.open(url)).start()
    try:
        server.run()
    except KeyboardInterrupt:
        pass
    finally:
        server.close()


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0].startswith('-'):
        argv.insert(0, 'run')
    parser = argparse.ArgumentParser(description='Portable Infinity Job Shortlist, signed IBM chat without an API key')
    commands = parser.add_subparsers(dest='command', required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument('--config-dir', type=Path)
    launch = commands.add_parser('run', parents=[common])
    launch.add_argument('--port', type=int, default=8080)
    launch.add_argument('--host')
    launch.add_argument('--server', action='store_true')
    launch.add_argument('--no-browser', action='store_true')
    setup = commands.add_parser('setup', parents=[common])
    setup.add_argument('--import-file', type=Path)
    commands.add_parser('doctor', parents=[common])
    export = commands.add_parser('export-connection', parents=[common])
    export.add_argument('output', type=Path)
    args = parser.parse_args(argv)
    directory = (args.config_dir or config_directory()).expanduser().resolve()
    if args.command == 'export-connection':
        password = getpass.getpass('New transfer password (12+ characters, hidden): ')
        if password != getpass.getpass('Repeat transfer password: '):
            raise ValueError('Passwords do not match')
        private_write(args.output, encrypted_connection(directory, password))
        print('Encrypted connection saved: ' + str(args.output))
    elif args.command == 'setup':
        ensure_connection(directory, args.import_file)
        widget = configure(directory)
        print('Connection ready. Lead agent: ' + widget['chatOptions']['agentId'])
        print('The lead uses its deployed Company Assessment collaborator. Start the app next.')
    elif args.command == 'doctor':
        widget = configure(directory)
        from service.orchestrate_embed import create_session
        session = create_session()
        print(json.dumps({'python': sys.version.split()[0], 'connection_directory': str(directory),
                          'signed_token_created': bool(session['token']), 'ibm_host': widget['hostURL'],
                          'lead_agent': widget['chatOptions']['agentId'], 'environment': widget['chatOptions']['agentEnvironmentId'],
                          'api_key_required': False, 'note': 'Local signing verified; no IBM inference or network authentication test performed.'}, indent=2))
    else:
        run(args, directory)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
        print('Could not start: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
