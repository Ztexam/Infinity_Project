"""Small HTTPS JSON client with an explicit destination allowlist and bounded reads."""
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request


class SourceError(RuntimeError):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class JsonHTTP:
    def __init__(self, hosts, user_agent, timeout=25, max_bytes=25_000_000):
        self.hosts = set(hosts)
        self.user_agent = user_agent
        self.timeout = timeout
        self.max_bytes = max_bytes
        self.lock = threading.Lock()
        self.last_request = 0
        self.opener = urllib.request.build_opener(NoRedirect())

    def request(self, url, data=None, headers=None, content_type="application/json", retries=1):
        raw = self.read(url, data, headers, content_type, retries)
        try:
            return json.loads(raw)
        except (ValueError, UnicodeError) as exc:
            raise SourceError("Source returned invalid JSON") from exc

    def read(self, url, data=None, headers=None, content_type="application/json", retries=1):
        parts = urllib.parse.urlsplit(url)
        if parts.scheme != "https" or parts.hostname not in self.hosts or parts.port not in (None, 443) or parts.username or parts.password:
            raise SourceError("Unconfigured data destination")
        request_headers = {"User-Agent": self.user_agent, "Accept": "application/json", **(headers or {})}
        if data is not None:
            request_headers["Content-Type"] = content_type
        for attempt in range(retries + 1):
            # Serialize starts to stay below two requests/second per client, including retries.
            with self.lock:
                time.sleep(max(0, .55 - (time.monotonic() - self.last_request)))
                self.last_request = time.monotonic()
            req = urllib.request.Request(url, data=data, headers=request_headers)
            try:
                with self.opener.open(req, timeout=self.timeout) as response:
                    raw = response.read(self.max_bytes + 1)
                    if len(raw) > self.max_bytes:
                        raise SourceError("Source response exceeds the POC size limit")
                    return raw
            except urllib.error.HTTPError as exc:
                if exc.code in (429, 500, 502, 503, 504) and attempt < retries:
                    delay = exc.headers.get("Retry-After", "1")
                    time.sleep(min(5, max(1, int(delay))) if delay.isdigit() else 1)
                    continue
                # Do not log provider response bodies, tokens, or request headers.
                raise SourceError("Upstream HTTP " + str(exc.code)) from None
            except (OSError, ValueError) as exc:
                raise SourceError("Source request failed or returned invalid JSON") from None
