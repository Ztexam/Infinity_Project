"""Explicit local verification and live source collection; no hidden inference."""
import argparse
import json
import socket
from socketserver import ThreadingMixIn
import webbrowser
from wsgiref.simple_server import WSGIServer, make_server

from .app import Application, app
from .engine import Engine


class LocalServer(ThreadingMixIn, WSGIServer):
    daemon_threads = True
    allow_reuse_address = not hasattr(socket, "SO_EXCLUSIVEADDRUSE")

    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def main():
    parser = argparse.ArgumentParser(description="IBM jobs service")
    parser.add_argument("command", choices=("serve", "status", "refresh", "search", "export"))
    parser.add_argument("--companies", help="Comma-separated configured IDs; default all ten")
    parser.add_argument("--sources", default="jobs,financials")
    parser.add_argument("--skills", default="Python,SQL")
    parser.add_argument("--use-cached", action="store_true")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--local-browser", action="store_true", help="Allow same-origin browser requests on localhost")
    parser.add_argument("--open-browser", action="store_true", help="Open the local shortlist once the server is listening")
    parser.add_argument("--output", default="runtime_cache/ibm/exports")
    args = parser.parse_args()
    if args.command == "serve":
        host = f"localhost:{args.port}"
        application = Application(local_browser_host=host) if args.local_browser else app
        with make_server("127.0.0.1", args.port, application, server_class=LocalServer) as server:
            url = f"http://{host}/live"
            print(f"Shortlist app running at {url}", flush=True)
            if args.open_browser:
                webbrowser.open(url)
            server.serve_forever()
        return
    engine = Engine()
    if args.command == "status":
        result = engine.status()
    elif args.command == "export":
        result = engine.export(args.output)
    elif args.command == "refresh":
        result = engine.refresh(args.companies.split(",") if args.companies else None, args.sources.split(","))
    else:
        result = engine.search({"skills": args.skills.split(","), "freshness": "use_cached" if args.use_cached else "refresh_if_stale"})
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
