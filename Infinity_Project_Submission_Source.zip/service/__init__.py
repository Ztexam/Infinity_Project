"""IBM-hosted service; source collection and financial arithmetic use no AI."""
