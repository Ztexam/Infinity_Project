"""WSGI API. Synchronous requests keep work attached to Code Engine request life.

Production entrypoint: gunicorn --workers 1 --threads 2 --timeout 900 service.app:app
The access token is entered by demo operators, never embedded in frontend files.
"""
import hmac
import json
import os
from pathlib import Path
import threading

_LIVE_HTML = Path(__file__).resolve().parent.parent / "frontend" / "live.html"

from poc.backend import AgentError, ROOT
from .engine import Engine, validate_profile
from . import orchestrate_embed


class Application:
    def __init__(self, engine=None, access_token=None, local_browser_host=None):
        self._engine = engine
        self.access_token = access_token
        self.local_browser_host = local_browser_host
        self.init_lock = threading.Lock()

    @property
    def engine(self):
        with self.init_lock:
            if self._engine is None:
                self._engine = Engine()
        return self._engine

    def __call__(self, environ, start_response):
        def respond(code, value):
            body = json.dumps(value, ensure_ascii=False, allow_nan=False).encode()
            start_response(code, [("Content-Type", "application/json; charset=utf-8"), ("Content-Length", str(len(body))),
                ("Cache-Control", "no-store"), ("X-Content-Type-Options", "nosniff")])
            return [body]

        path, method = environ.get("PATH_INFO", "/"), environ.get("REQUEST_METHOD", "GET")
        loopback = self.local_browser_host and environ.get("REMOTE_ADDR") == "127.0.0.1"
        local_page = bool(loopback and environ.get("HTTP_HOST") == self.local_browser_host)
        if path == "/live" and method == "GET":
            if loopback and environ.get("HTTP_HOST") == self.local_browser_host.replace("localhost:", "127.0.0.1:"):
                start_response("302 Found", [("Location", f"http://{self.local_browser_host}/live"), ("Cache-Control", "no-store")])
                return [b""]
            if not _LIVE_HTML.is_file():
                return respond("404 Not Found", {"error": "Live view not found"})
            body = _LIVE_HTML.read_bytes()
            start_response("200 OK", [("Content-Type", "text/html; charset=utf-8"),
                ("Content-Length", str(len(body))), ("Cache-Control", "no-store"),
                ("X-Content-Type-Options", "nosniff")])
            return [body]
        if path == "/api/health" and method == "GET":
            return respond("200 OK", {"status": "ok", "service": "shortlist-ibm",
                "inference_enabled": os.getenv("INFERENCE_ENABLED", "false").lower() == "true",
                "orchestrate_embed_configured": orchestrate_embed.configured(), "local_browser_access": local_page})
        if path == "/api/data/status" and method == "GET":
            return respond("200 OK", self.engine.status())
        if path not in ("/api/search", "/api/data/refresh", "/api/operator/usage", "/api/orchestrate/prepare",
                        "/api/orchestrate/embed-token", "/api/orchestrate/shortlist"):
            return respond("404 Not Found", {"error": "Unknown route"})
        required = "GET" if path == "/api/operator/usage" else "POST"
        if method != required:
            return respond("405 Method Not Allowed", {"error": "Use " + required})
        token = self.access_token if self.access_token is not None else os.getenv("APP_ACCESS_TOKEN", "")
        local_access = local_page and method == "POST" and environ.get("HTTP_ORIGIN") == f"http://{self.local_browser_host}"
        if not token and not local_access and not local_page:
            return respond("503 Service Unavailable", {"error": "Configure the demo access token before enabling API operations"})
        supplied = environ.get("HTTP_AUTHORIZATION", "")
        if not local_access and not (token and hmac.compare_digest(supplied.encode(), ("Bearer " + token).encode())):
            return respond("401 Unauthorized", {"error": "Open the app at localhost or provide an operator token"})
        if path == "/api/operator/usage":
            return respond("200 OK", self.engine.store.allowance())
        if path == "/api/orchestrate/embed-token":
            if not orchestrate_embed.configured():
                return respond("503 Service Unavailable", {"error": "Embedded IBM Chat is not configured for this service."})
            try:
                return respond("200 OK", orchestrate_embed.create_session())
            except (ImportError, KeyError, OSError, TypeError, ValueError):
                return respond("503 Service Unavailable", {"error": "The service could not sign an IBM Chat token. Check the embed configuration and signing key."})
        try:
            length = int(environ.get("CONTENT_LENGTH") or 0)
            if length < 1 or length > 8192:
                raise ValueError("Send a JSON body between 1 and 8192 bytes")
            if environ.get("CONTENT_TYPE", "").split(";")[0] != "application/json":
                raise ValueError("Use application/json")
            payload = json.loads(environ["wsgi.input"].read(length))
            if path in ("/api/search", "/api/orchestrate/prepare", "/api/orchestrate/shortlist"):
                validate_profile(payload)
            elif not isinstance(payload, dict) or set(payload) - {"company_ids", "sources"}:
                raise ValueError("Refresh accepts company_ids and sources only")
        except (ValueError, UnicodeError):
            return respond("400 Bad Request", {"error": "Invalid request body or unsupported search/refresh parameters"})
        # One expensive operation at a time; status remains readable on the other thread.
        if not self.engine.store.operation_lock.acquire(blocking=False):
            return respond("409 Conflict", {"error": "A search or data refresh is already running"})
        try:
            if path == "/api/search":
                result = self.engine.search(payload)
            elif path == "/api/orchestrate/prepare":
                result = self.engine.prepare_orchestrate(payload)
            elif path == "/api/orchestrate/shortlist":
                result = self.engine.prepare_company_shortlist(payload)
            else:
                result = self.engine.refresh(payload.get("company_ids"), payload.get("sources"))
            return respond("200 OK", result)
        except ValueError:
            return respond("400 Bad Request", {"error": "Unsupported input parameters"})
        except AgentError as exc:
            return respond("503 Service Unavailable", {"error": str(exc), "state": "failed", "simulated_result": False})
        except Exception:
            # Never put credentials, provider bodies, stack traces or source text in API errors.
            return respond("500 Internal Server Error", {"error": "Service could not complete the request", "state": "failed"})
        finally:
            self.engine.store.operation_lock.release()


app = Application()
