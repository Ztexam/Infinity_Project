"""Sign short-lived tokens for the IBM Orchestrate embedded chat."""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import time


CONFIG = "ORCHESTRATE_EMBED_CONFIG"
KEY_FILE = "ORCHESTRATE_EMBED_PRIVATE_KEY_FILE"
TOKEN_LIFETIME_SECONDS = 600


def configured():
    return bool(os.getenv(CONFIG) and os.getenv(KEY_FILE))


def base64url(data):
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def create_session():
    # Optional dependency for the embed. The public-data service can run without it.
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding, rsa

    config = json.loads(os.environ[CONFIG])
    host = config["hostURL"]
    if not re.fullmatch(r"https://[a-z0-9-]+\.watson-orchestrate\.cloud\.ibm\.com", host):
        raise ValueError("The embed host must be an IBM Cloud Orchestrate origin")
    # Only allow the public values from IBM's generated snippet into the browser.
    chat = config["chatOptions"]
    widget = {"hostURL": host, "deploymentPlatform": "ibmcloud", "crn": config["crn"],
              "orchestrationID": config["orchestrationID"],
              "chatOptions": {"agentId": chat["agentId"], "agentEnvironmentId": chat["agentEnvironmentId"]}}

    key = serialization.load_pem_private_key(Path(os.environ[KEY_FILE]).read_bytes(), password=None)
    if not isinstance(key, rsa.RSAPrivateKey) or key.key_size < 2048:
        raise ValueError("Configure an RSA signing key of at least 2048 bits")
    public_der = key.public_key().public_bytes(serialization.Encoding.DER,
                                              serialization.PublicFormat.SubjectPublicKeyInfo)
    # The shared local demo token authenticates one operator identity.
    subject = "shortlist-" + hashlib.sha256(public_der).hexdigest()[:32]
    now = int(time.time())
    expires_at = now + TOKEN_LIFETIME_SECONDS
    claims = {"sub": subject, "iat": now, "exp": expires_at}
    header = base64url(b'{"alg":"RS256","typ":"JWT"}')
    payload = base64url(json.dumps(claims, separators=(",", ":")).encode("ascii"))
    signing_input = f"{header}.{payload}".encode("ascii")
    signature = key.sign(signing_input, padding.PKCS1v15(), hashes.SHA256())
    return {"widget": widget, "token": f"{header}.{payload}.{base64url(signature)}", "expires_at": expires_at}
