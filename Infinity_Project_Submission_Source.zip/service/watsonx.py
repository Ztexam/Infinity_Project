"""watsonx REST adapter for the existing bounded two-agent protocol.

No default model is assumed to remain available. Choose a tool-capable Granite
model from the actual project's catalog after checking the account's Lite plan.
"""
import json
import os
import time
from urllib.parse import urlencode, urlsplit

from poc.backend import AgentError
from .http_client import JsonHTTP, SourceError

REGIONS = ("us-south", "eu-de", "eu-gb", "jp-tok", "au-syd", "ca-tor")


class WatsonxClient:
    def __init__(self, store, *, api_key=None, project_id=None, model=None, url=None,
                 enabled=None, http=None, max_calls=7, max_tokens=1500,
                 monthly_budget=150_000, max_payload_bytes=45_000):
        self.api_key = api_key if api_key is not None else os.getenv("IBM_CLOUD_API_KEY", "")
        self.project_id = project_id or os.getenv("WATSONX_PROJECT_ID", "")
        self.model = model or os.getenv("WATSONX_MODEL_ID", "")
        self.url = (url or os.getenv("WATSONX_URL", "https://us-south.ml.cloud.ibm.com")).rstrip("/")
        self.version = "2024-05-31"
        self.enabled = (os.getenv("INFERENCE_ENABLED", "false").lower() == "true") if enabled is None else enabled
        if self.url not in {f"https://{region}.ml.cloud.ibm.com" for region in REGIONS}:
            raise AgentError("Configure a supported IBM regional watsonx endpoint")
        self.http = http or JsonHTTP({"iam.cloud.ibm.com", urlsplit(self.url).hostname}, "ShortlistPOC/0.1", timeout=90, max_bytes=2_000_000)
        self.store = store
        self.max_calls, self.max_tokens = max_calls, max_tokens
        self.monthly_budget, self.max_payload_bytes = monthly_budget, max_payload_bytes
        self.calls = 0
        self.usage = []
        self.token, self.expires_at = "", 0
        self.cache_identity = "watsonx:" + self.url + ":" + self.model

    def check_configuration(self):
        missing = [name for name, value in (("IBM_CLOUD_API_KEY", self.api_key), ("WATSONX_PROJECT_ID", self.project_id), ("WATSONX_MODEL_ID", self.model)) if not value]
        if missing:
            raise AgentError("IBM setup required: " + ", ".join(missing))
        if not self.enabled:
            raise AgentError("IBM inference is disabled until the account/allowance check is complete")

    def bearer(self):
        if self.token and time.time() < self.expires_at - 60:
            return self.token
        payload = urlencode({"grant_type": "urn:ibm:params:oauth:grant-type:apikey", "apikey": self.api_key}).encode()
        result = self.http.request("https://iam.cloud.ibm.com/identity/token", data=payload,
            content_type="application/x-www-form-urlencoded", retries=0)
        if not isinstance(result.get("access_token"), str):
            raise AgentError("IBM IAM returned no access token")
        self.token = result["access_token"]
        self.expires_at = time.time() + min(int(result.get("expires_in", 300)), 3600)
        return self.token

    def chat(self, messages, tools, format_schema=None):
        self.check_configuration()
        if self.calls >= self.max_calls:
            raise AgentError("Search reached the seven-call IBM inference limit")
        wire_messages = []
        for message in messages:
            wire = {k: message[k] for k in ("role", "content", "tool_calls", "tool_call_id") if k in message}
            if wire.get("content") is None:
                wire["content"] = ""
            wire_messages.append(wire)
        payload = {"model_id": self.model, "project_id": self.project_id, "messages": wire_messages,
                   "max_tokens": self.max_tokens, "temperature": 0}
        if tools:
            payload.update(tools=tools, tool_choice_option="required")
        else:
            # JSON-object mode is more portable across Granite models than JSON-schema mode.
            # The application's validator still enforces the dynamic output schema.
            payload["response_format"] = {"type": "json_object"}
        encoded = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode()
        if len(encoded) > self.max_payload_bytes:
            raise AgentError("Agent context exceeds the compact POC request limit")
        # Reserve payload bytes + generation tokens + protocol overhead before sending.
        # Do not refund on failure; provider tokenization and unrelated account usage vary.
        reservation = len(encoded) + self.max_tokens + 1024
        if not self.store.reserve_tokens(reservation, self.monthly_budget):
            raise AgentError("POC inference allowance reached; no further model request was sent")
        self.calls += 1
        try:
            result = self.http.request(self.url + "/ml/v1/text/chat?version=" + self.version,
                data=encoded, headers={"Authorization": "Bearer " + self.bearer()}, retries=0)
        except SourceError as exc:
            raise AgentError("IBM model request failed (" + str(exc) + "). No simulated result was generated.") from None
        choices = result.get("choices", [])
        if not choices or not isinstance(choices[0].get("message"), dict):
            raise AgentError("IBM returned no chat message")
        if choices[0].get("finish_reason") in ("length", "content_filter"):
            raise AgentError("IBM response was incomplete; do not display a partial assessment")
        usage = result.get("usage", {})
        self.usage.append({"input_tokens": usage.get("prompt_tokens"), "output_tokens": usage.get("completion_tokens"),
                           "reserved_token_units": reservation})
        return {"message": choices[0]["message"], "model": self.model,
                "prompt_eval_count": usage.get("prompt_tokens"), "eval_count": usage.get("completion_tokens")}
