"""Atomic per-source cache and a conservative inference allowance ledger."""
from contextlib import contextmanager
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
import threading

from .sources import utcnow


class Store:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / "service.sqlite3"
        self.operation_lock = threading.Lock()
        with self.connection() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS sources (
                  company_id TEXT, source TEXT, payload TEXT, fetched_at TEXT,
                  attempted_at TEXT, status TEXT, message TEXT,
                  PRIMARY KEY(company_id, source));
                CREATE TABLE IF NOT EXISTS allowance (
                  month TEXT PRIMARY KEY, reserved_tokens INTEGER NOT NULL);
            ''')

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    def record(self, company_id, source):
        with self.connection() as db:
            row = db.execute("SELECT * FROM sources WHERE company_id=? AND source=?", (company_id, source)).fetchone()
        return dict(row) if row else None

    def records(self):
        """Read one consistent source snapshot instead of opening SQLite per row."""
        with self.connection() as db:
            return {(row['company_id'], row['source']): dict(row) for row in db.execute('SELECT * FROM sources')}

    def save(self, company_id, source, payload, fetched_at=None):
        stamp = fetched_at or utcnow()
        with self.connection() as db:
            db.execute("INSERT OR REPLACE INTO sources VALUES (?, ?, ?, ?, ?, 'ready', '')",
                       (company_id, source, json.dumps(payload), stamp, utcnow()))

    def failed(self, company_id, source, message):
        with self.connection() as db:
            db.execute("INSERT INTO sources VALUES (?, ?, NULL, NULL, ?, 'failed', ?) "
                       "ON CONFLICT(company_id,source) DO UPDATE SET attempted_at=excluded.attempted_at, status='failed', message=excluded.message",
                       (company_id, source, utcnow(), message))

    @staticmethod
    def age(stamp):
        if not stamp:
            return float("inf")
        return (datetime.now(timezone.utc) - datetime.fromisoformat(stamp)).total_seconds()

    def reserve_tokens(self, amount, limit):
        month = datetime.now(timezone.utc).strftime("%Y-%m")
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT OR IGNORE INTO allowance VALUES (?, 0)", (month,))
            used = db.execute("SELECT reserved_tokens FROM allowance WHERE month=?", (month,)).fetchone()[0]
            if used + amount > limit:
                return False
            db.execute("UPDATE allowance SET reserved_tokens=reserved_tokens+? WHERE month=?", (amount, month))
        return True

    def allowance(self):
        month = datetime.now(timezone.utc).strftime("%Y-%m")
        with self.connection() as db:
            row = db.execute("SELECT reserved_tokens FROM allowance WHERE month=?", (month,)).fetchone()
        return {"month": month, "reserved_token_units": row[0] if row else 0,
                "note": "Conservative reservations, not billed tokens. Only this cache volume is counted; container replacement can reset an ephemeral volume."}
