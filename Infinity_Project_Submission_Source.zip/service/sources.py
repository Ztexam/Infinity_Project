"""Free public Greenhouse/SEC adapters. Preserve periods and derivation evidence."""
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from html import unescape
from html.parser import HTMLParser
import math
import re
from urllib.parse import urlencode, urlsplit
from xml.etree import ElementTree

from .http_client import JsonHTTP, SourceError

METRICS = {
    "revenue": ("RevenueFromContractWithCustomerExcludingAssessedTax", "RevenueFromContractWithCustomerIncludingAssessedTax", "Revenues", "SalesRevenueNet"),
    "operating_cash_flow": ("NetCashProvidedByUsedInOperatingActivities",),
    "research_and_development": ("ResearchAndDevelopmentExpense",),
}
IFRS_METRICS = {
    "revenue": ("Revenue", "RevenueFromContractsWithCustomers"),
    "operating_cash_flow": ("CashFlowsFromUsedInOperatingActivities",),
    "research_and_development": ("ResearchAndDevelopmentExpense",),
}
GAAP_FORMS = ("10-K", "10-Q", "10-K/A", "10-Q/A")
IFRS_FORMS = ("20-F", "6-K", "20-F/A", "6-K/A")
SKILLS = ("Python", "SQL", "Java", "JavaScript", "TypeScript", "React", "Go", "C++", "C#", "Rust",
          "AWS", "Kubernetes", "Docker", "Linux", "Spark", "Scala", "machine learning", "distributed systems", "HRIS")
TECH_ROLE = re.compile(
    r"(?:software|backend|back.end|frontend|front.end|full.stack|platform|infrastructure|machine learning|site reliability|security).*engineer"
    r"|engineer.*(?:software|backend|frontend|platform|infrastructure)"
    r"|\b(?:AI|DevOps|data|analytics)\b.*\bengineer\b|\b(?:data scientist|execution developer|quantitative research developer|C\+\+ developer)\b"
    r"|\b(?:HRIS|HR systems|people systems|HR technology|human resources information systems?)\b"
    r"|\bWorkday\b.*\b(?:analyst|architect|developer|engineer|integration|specialist|solutions|systems)\b"
    r"|\b(?:analyst|architect|developer|director|engineer|integration|manager|specialist|solutions|systems)\b.*\bWorkday\b",
    re.I,
)


def utcnow():
    return datetime.now(timezone.utc).isoformat()


class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.ignored = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.ignored += 1
        if tag in ("p", "li", "br", "h1", "h2", "h3", "div"):
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self.ignored:
            self.ignored -= 1

    def handle_data(self, data):
        if not self.ignored:
            self.parts.append(data)


def plain_text(value):
    parser = TextExtractor()
    parser.feed(unescape(unescape(value or "")))
    return re.sub(r"[ \t]+", " ", "".join(parser.parts)).strip()


def skill_mentions(text, skills=SKILLS):
    return [s for s in skills if re.search(r"(?<!\w)" + re.escape(s) + r"(?!\w)", text, re.I)]


def normalize_jobs(payload, company, fetched_at, limit=None):
    if not isinstance(payload, dict) or not isinstance(payload.get("jobs"), list):
        raise SourceError("Greenhouse response has no jobs array")
    rows = {}
    for raw in payload["jobs"]:
        title = raw.get("title", "")
        is_tech_role = TECH_ROLE.search(title)
        if not is_tech_role and not re.search(r"\b(?:compensation|payroll)\b", title, re.I):
            continue
        if re.search(r"\bintern(?:ship)?\b", title, re.I):
            continue
        location = (raw.get("location") or {}).get("name") or ""
        locations = [("location.name", location)]
        locations += [("offices.location", str(o.get("location") or "")) for o in raw.get("offices") or []]
        for item in raw.get("metadata") or []:
            # Only explicit location metadata counts; descriptions may mention the HQ.
            if "location" in str(item.get("name", "")).lower():
                locations.append(("metadata." + item["name"], str(item.get("value", ""))))
        evidence = [{"field": field, "value": value} for field, value in locations if value.strip()]
        if not evidence:
            continue
        url = raw.get("absolute_url", "")
        if urlsplit(url).scheme != "https" or not urlsplit(url).hostname:
            continue
        text = plain_text(raw.get("content", ""))
        if not text:
            continue
        if not is_tech_role and not re.search(r"\b(?:Workday administration|HRIS data)\b", text, re.I):
            continue
        source_id = str(raw.get("id", ""))
        lever = company.get("job_board_provider") == "Lever"
        if not (re.fullmatch(r"[a-f0-9-]{36}", source_id) if lever else source_id.isdigit()):
            continue
        jid = company["company_id"] + ":" + source_id
        # Keep a small source sample, but enough text for user-supplied skill matching.
        rows[jid] = {"job_id": jid, "company_id": company["company_id"], "source_job_id": source_id,
            "title": title[:250], "location_raw": location[:500], "location_evidence": evidence,
            "description_excerpt": text[:6000], "description_truncated": len(text) > 6000,
            "skills_mentioned": skill_mentions(title + " " + text), "application_url": url,
            "source_api_url": company["jobs_api_url"] + "/" + source_id,
            "source_updated_at": raw.get("updated_at"), "collected_at_utc": fetched_at,
            "availability": "Published in the employer API at collection; may subsequently close."}
    return [rows[k] for k in sorted(rows)[:limit]]


def lever_jobs(postings):
    if not isinstance(postings, list):
        raise SourceError("Lever response has no postings array")
    jobs = []
    for post in postings:
        categories = post.get("categories") or {}
        locations = list(categories.get("allLocations") or [])
        if post.get("workplaceType") == "remote":
            locations.append("Remote")
        jobs.append({"id": post.get("id"), "title": post.get("text") or "",
                     "location": {"name": categories.get("location")},
                     "offices": [{"location": location} for location in locations],
                     "absolute_url": post.get("hostedUrl") or "",
                     "content": "\n".join([post.get("description") or "",
                                           *(section.get("content") or "" for section in post.get("lists") or []),
                                           post.get("additional") or ""])})
    return {"jobs": jobs}


def periodic_filings(submissions, cik, report_prefix=None):
    recent = submissions.get("filings", {}).get("recent", {})
    forms = IFRS_FORMS if report_prefix else GAAP_FORMS[:2]
    for i, form in enumerate(recent.get("form", [])):
        if form not in forms:
            continue
        accession = recent["accessionNumber"][i]
        document = recent["primaryDocument"][i]
        period = recent["reportDate"][i]
        if not re.fullmatch(r"\d{10}-\d{2}-\d{6}", accession) or not re.fullmatch(r"[\w.-]+\.html?", document):
            continue
        if report_prefix and (not period or document != f"{report_prefix}-{period.replace('-', '')}.htm"):
            continue
        yield {"form": form, "reportDate": period,
                "filingDate": recent["filingDate"][i], "accession_number": accession,
                "filing_url": f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{accession.replace('-', '')}/{document}"}


def add_inline_ifrs_facts(facts, filing, document):
    try:
        root = ElementTree.fromstring(document)
    except ElementTree.ParseError as exc:
        raise SourceError("SEC inline XBRL could not be parsed") from exc
    xbrl = "{http://www.xbrl.org/2003/instance}"
    contexts = {}
    for context in root.iter(xbrl + "context"):
        if any(node.tag in (xbrl + "segment", xbrl + "scenario") for node in context.iter()):
            continue
        identifier = context.findtext(f"{xbrl}entity/{xbrl}identifier", "")
        start = context.findtext(f"{xbrl}period/{xbrl}startDate")
        end = context.findtext(f"{xbrl}period/{xbrl}endDate")
        if start and end and identifier.lstrip("0") == str(facts["cik"]).lstrip("0"):
            contexts[context.attrib["id"]] = (start, end)
    usd_units = {unit.attrib["id"] for unit in root.iter(xbrl + "unit")
                 if (unit.findtext(xbrl + "measure") or "").split(":")[-1] == "USD"}
    tags = {f"ifrs-full:{tag}": tag for names in IFRS_METRICS.values() for tag in names}
    taxonomy = facts.setdefault("facts", {}).setdefault("ifrs-full", {})
    for node in root.iter("{http://www.xbrl.org/2013/inlineXBRL}nonFraction"):
        tag = tags.get(node.get("name"))
        dates = contexts.get(node.get("contextRef"))
        if not tag or not dates or node.get("unitRef") not in usd_units:
            continue
        raw = "".join(node.itertext()).strip().replace(",", "")
        if node.get("format", "").endswith(":fixed-zero"):
            raw = "0"
        try:
            scale = int(node.get("scale", "0"))
            value = Decimal(raw).scaleb(scale)
        except (InvalidOperation, ValueError):
            continue
        if not value.is_finite() or not 0 <= scale <= 9:
            continue
        if node.get("sign") == "-":
            value = -value
        taxonomy.setdefault(tag, {}).setdefault("units", {}).setdefault("USD", []).append({
            "start": dates[0], "end": dates[1], "val": float(value), "form": filing["form"],
            "filed": filing["filingDate"], "accn": filing["accession_number"],
        })


def quarter_values(facts, tags, cutoff, taxonomy="us-gaap", forms=GAAP_FORMS, merge_tags=False):
    # Pick the latest filed observation for each exact duration, within one tag.
    # Prefer an actual quarter; otherwise difference cumulative facts sharing a start.
    quarters = {}
    tag_groups = (tags,) if merge_tags else [(tag,) for tag in reversed(tags)]
    for group in tag_groups:
        observations = {}
        for tag in group:
            for f in facts.get("facts", {}).get(taxonomy, {}).get(tag, {}).get("units", {}).get("USD", []):
                if f.get("form") not in forms or not f.get("start") or f.get("end", "") > cutoff:
                    continue
                if not isinstance(f.get("val"), (int, float)) or not math.isfinite(f["val"]):
                    continue
                start, end = date.fromisoformat(f["start"]), date.fromisoformat(f["end"])
                if not 65 <= (end - start).days + 1 <= 380:
                    continue
                key = (f["start"], f["end"])
                if key not in observations or (f.get("filed", ""), f.get("accn", "")) > (observations[key].get("filed", ""), observations[key].get("accn", "")):
                    observations[key] = {**f, "source_tag": tag}
        tag_quarters = {}

        def evidence(f):
            return {"taxonomy": taxonomy, "tag": f["source_tag"], "unit": "USD", "period_start": f["start"],
                "period_end": f["end"], "value": f["val"], "filed_at": f.get("filed"),
                "accession_number": f.get("accn"), "form": f.get("form")}

        for (start, end), f in observations.items():
            duration = (date.fromisoformat(end) - date.fromisoformat(start)).days + 1
            if duration <= 110:
                tag_quarters[(start, end)] = {"value": f["val"], "method": "reported_quarter", "source_facts": [evidence(f)]}
            else:
                prefixes = [p for (s, e), p in observations.items() if s == start and
                            65 <= (date.fromisoformat(end) - date.fromisoformat(e)).days <= 110]
                if prefixes:
                    prefix = max(prefixes, key=lambda p: p["end"])
                    quarter_start = (date.fromisoformat(prefix["end"]) + timedelta(days=1)).isoformat()
                    key = (quarter_start, end)
                    if key not in tag_quarters or tag_quarters[key]["method"] != "reported_quarter":
                        tag_quarters[key] = {"value": f["val"] - prefix["val"],
                            "method": "cumulative_end_minus_cumulative_previous_quarter",
                            "source_facts": [evidence(f), evidence(prefix)]}
        quarters.update(tag_quarters)
    return quarters


def normalize_financials(facts, submissions, company, fetched_at):
    if str(facts.get("cik", "")).lstrip("0") != company["cik"].lstrip("0"):
        raise SourceError("SEC company identity mismatch")
    report_prefix = company.get("sec_ifrs_report_prefix")
    filing = next(periodic_filings(submissions, company["cik"], report_prefix), None)
    if not filing:
        raise SourceError("No supported periodic filing found")
    taxonomy, forms, metrics = ("ifrs-full", IFRS_FORMS, IFRS_METRICS) if report_prefix else ("us-gaap", GAAP_FORMS, METRICS)
    maps = {metric: quarter_values(facts, tags, filing["reportDate"], taxonomy, forms,
                                  merge_tags=bool(report_prefix and metric == "revenue"))
            for metric, tags in metrics.items()}
    common = set.intersection(*(set(rows) for rows in maps.values()))
    periods = sorted(common, key=lambda p: p[1])[-8:]
    if len(periods) != 8 or periods[-1][1] != filing["reportDate"]:
        raise SourceError("Eight aligned quarters through the latest filing are unavailable")
    if any(date.fromisoformat(periods[i][0]) != date.fromisoformat(periods[i-1][1]) + timedelta(days=1) for i in range(1, 8)):
        raise SourceError("Financial quarters are not contiguous")
    if any(not 350 <= (date.fromisoformat(periods[i+4][1])-date.fromisoformat(periods[i][1])).days <= 380 for i in range(4)):
        raise SourceError("Year-over-year periods are not comparable")
    quarters = [{"period_start": s, "period_end": e, "unit": "USD", "window": "preceding_four" if i < 4 else "latest_four",
                 **{metric: rows[(s, e)] for metric, rows in maps.items()}} for i, (s, e) in enumerate(periods)]
    if not report_prefix and len({f["tag"] for q in quarters for f in q["revenue"]["source_facts"]}) != 1:
        raise SourceError("Revenue basis changed across comparison periods; manual review is required")
    totals = lambda rows: {m: sum(q[m]["value"] for q in rows) for m in METRICS}
    current, previous = totals(quarters[4:]), totals(quarters[:4])
    if current["revenue"] <= 0 or previous["revenue"] <= 0 or previous["research_and_development"] <= 0:
        raise SourceError("Financial denominators are unavailable or nonpositive")
    nonpositive = sum(q["operating_cash_flow"]["value"] <= 0 for q in quarters[4:])
    inputs = {"latest_four_totals_usd": current, "preceding_four_totals_usd": previous,
        "operating_cash_flow_margin_pct": 100 * current["operating_cash_flow"] / current["revenue"],
        "revenue_growth_yoy_pct": 100 * (current["revenue"] / previous["revenue"] - 1),
        "research_and_development_change_yoy_pct": 100 * (current["research_and_development"] / previous["research_and_development"] - 1),
        "positive_operating_cash_flow_quarters": 4 - nonpositive, "nonpositive_operating_cash_flow_quarters": nonpositive}
    return {"company_id": company["company_id"], "cik": company["cik"], "ticker": company["ticker"],
        "source_api_url": company["financials_api_url"], "collected_at_utc": fetched_at,
        "latest_periodic_filing": filing, "quarters": quarters, "calculated_inputs": inputs,
        "normalization_note": "Latest-filed USD entity facts for exact periods; cumulative cash flow is differenced, never summed as quarters. R&D is reported spending, not a future budget."}


class PublicSources:
    def __init__(self, sec_user_agent="", http=None):
        self.sec_user_agent = sec_user_agent
        self.http = http or JsonHTTP({"boards-api.greenhouse.io", "api.lever.co"}, "ShortlistPOC/0.1", timeout=12)
        self.lever_http = http or JsonHTTP({"api.lever.co"}, "ShortlistPOC/0.1", timeout=12)
        self.sec_http = http or JsonHTTP({"data.sec.gov", "www.sec.gov"}, "ShortlistPOC/0.1")
        self.search_http = http or JsonHTTP({"veritahire.com"}, "ShortlistPOC/0.1", timeout=12)

    def jobs(self, company):
        # URLs come only from the checked-in company configuration.
        url = company["jobs_api_url"]
        if company.get("job_board_provider") == "Lever":
            payload = lever_jobs(self.lever_http.request(url + "?mode=json"))
        else:
            payload = self.http.request(url + "?content=true")
        return normalize_jobs(payload, company, utcnow())

    def discover_jobs(self, keyword, location):
        filters = {"what": keyword, "where": location, "radius_miles": 10}
        if location == "United States":
            filters["where"] = "US"
        if location.casefold() == "remote":
            filters.update(where="US", remote_only=1)
        url = "https://veritahire.com/api/jobs-search.php?" + urlencode(filters)
        payload = self.search_http.request(url, retries=0)
        if not isinstance(payload, dict) or not isinstance(payload.get("jobs"), list):
            raise SourceError("Live search returned an unexpected response")
        if not payload.get("place_found"):
            return [], True
        jobs = []
        for row in payload["jobs"]:
            if not isinstance(row, dict):
                continue
            identifier = str(row.get("job_id", ""))
            title = row.get("title")
            employer = row.get("employer")
            published_location = row.get("location")
            url = row.get("apply_url") or ""
            if not isinstance(url, str):
                continue
            parts = urlsplit(url)
            if (not identifier.isdigit() or not all(isinstance(field, str) and field.strip()
                    for field in (title, employer, published_location)) or parts.scheme != "https"
                    or not parts.hostname or parts.username or parts.password or not row.get("last_confirmed_on_employer_site")):
                continue
            evidence = [{"field": "published location", "value": published_location[:500]}]
            if row.get("remote") is True:
                evidence.append({"field": "work arrangement", "value": "Remote"})
            jobs.append({"job_id": "veritahire:" + identifier, "employer_name": employer[:250], "title": title[:250],
                         "location_raw": published_location[:500], "location_evidence": evidence,
                         "description_excerpt": "", "skills_mentioned": [], "application_url": url,
                         "discovery_url": "https://veritahire.com/j/" + identifier})
        return jobs, bool(payload.get("partial"))

    def issuer_directory(self):
        return self.sec_http.request("https://www.sec.gov/files/company_tickers.json",
                                     headers={"User-Agent": self.sec_user_agent}, retries=0)

    def financials(self, company):
        if not re.search(r"[^\s@]+@[^\s@]+\.[^\s@]+", self.sec_user_agent):
            raise SourceError("Configure SEC_USER_AGENT with a project contact email")
        headers = {"User-Agent": self.sec_user_agent}
        submissions = self.sec_http.request(company["company_identity_api_url"], headers=headers)
        facts = self.sec_http.request(company["financials_api_url"], headers=headers)
        if report_prefix := company.get("sec_ifrs_report_prefix"):
            for filing in periodic_filings(submissions, company["cik"], report_prefix):
                document = self.sec_http.read(filing["filing_url"], headers={**headers, "Accept": "text/html"})
                add_inline_ifrs_facts(facts, filing, document)
                if filing["form"] in ("20-F", "20-F/A"):
                    break
        return normalize_financials(facts, submissions, company, utcnow())
