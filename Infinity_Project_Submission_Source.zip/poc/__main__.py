import argparse
import json
from pathlib import Path

from .backend import AgentError, JobSystem


def main():
    parser = argparse.ArgumentParser(description="Two-agent local jobs POC")
    parser.add_argument("command", choices=["check", "run"])
    parser.add_argument("--skills", default="Python,SQL")
    parser.add_argument("--preference", default="")
    parser.add_argument("--model", default=None)
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--output", default="run_output.json")
    args = parser.parse_args()
    from .backend import OllamaClient
    app = JobSystem(client=OllamaClient(model=args.model), use_cache=not args.no_cache)
    if args.command == "check":
        evidence = app.financial_evidence(list(app.companies))
        assert len(app.companies) == 10 and len(app.jobs) == 42
        assert all(len(f["quarters"]) == 8 for f in app.financials.values())
        assert all(j["company_id"] in app.companies and j["san_francisco_location_evidence"] for j in app.jobs.values())
        print(json.dumps({"mode": "offline data and scoring check; no AI called", "companies": 10,
                          "jobs": 42, "quarters": 80,
                          "scoring_inputs_available": all(x["computed_score"]["score"] is not None for x in evidence)}, indent=2))
        return
    result = app.run(args.skills.split(","), args.preference)
    output = Path(args.output)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("Saved actual AI output to " + str(output.resolve()))
    for row in result["shortlist"]:
        print(row["company"] + " | " + row["title"] + " | company score " + str(row["company_assessment"]["score"]))


if __name__ == "__main__":
    try:
        main()
    except (AgentError, AssertionError, OSError) as exc:
        raise SystemExit("POC stopped: " + str(exc))

