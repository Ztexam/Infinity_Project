"""Two local AI agents for the San Francisco jobs POC."""

