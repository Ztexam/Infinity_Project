"""Provisional POC scoring rules; these are not validated financial benchmarks."""
RUBRIC_VERSION = "stability-poc-v1"


def band(value, bounds):
    for upper, score in bounds:
        if value < upper:
            return score
    raise ValueError("Missing terminal scoring band")


def score_company(inputs):
    required = ["operating_cash_flow_margin_pct", "revenue_growth_yoy_pct",
                "research_and_development_change_yoy_pct", "nonpositive_operating_cash_flow_quarters",
                "latest_four_totals_usd"]
    if any(inputs.get(key) is None for key in required):
        return {"score": None, "eligible": False, "reason": "Insufficient financial evidence"}
    return weighted_score(inputs["operating_cash_flow_margin_pct"], inputs["revenue_growth_yoy_pct"],
                          inputs["research_and_development_change_yoy_pct"],
                          inputs["latest_four_totals_usd"].get("operating_cash_flow", 0),
                          inputs["nonpositive_operating_cash_flow_quarters"])


def weighted_score(cash_margin, revenue_growth, rd_change, operating_cash_flow, nonpositive_quarters=0):
    cash = band(cash_margin,
                [(0, 0), (5, 4), (10, 6), (20, 8), (float("inf"), 10)])
    cash = max(0, cash - nonpositive_quarters)
    growth = band(revenue_growth,
                  [(-10, 0), (0, 3), (5, 6), (10, 8), (float("inf"), 10)])
    rd = 0 if rd_change < -15 else 4 if rd_change < -5 else 7 if rd_change < 0 else 10
    unrounded = .5 * cash + .3 * growth + .2 * rd
    positive_cash = operating_cash_flow > 0
    return {"score": round(unrounded, 2), "eligible": unrounded > 5 and positive_cash,
            "cash_flow_score": cash, "growth_score": growth, "rd_score": rd,
            "positive_total_operating_cash_flow": positive_cash,
            "rubric_version": RUBRIC_VERSION, "threshold": "strictly greater than 5",
            "weights": {"cash_flow": .5, "growth": .3, "rd": .2}}


def score_half_year(report):
    revenue = report.get("reported_revenue_usd")
    prior_revenue = report.get("prior_year_reported_revenue_usd")
    cash = report.get("operating_cash_flow_usd")
    rd = report.get("rd_spending_usd")
    prior_rd = report.get("prior_year_rd_spending_usd")
    if None in (revenue, prior_revenue, cash, rd, prior_rd) or min(revenue, prior_revenue, prior_rd) <= 0:
        return {"score": None, "eligible": False, "reason": "Insufficient half-year evidence"}
    # Six-month statements do not establish intra-period cash flow consistency.
    result = weighted_score(100 * cash / revenue, 100 * (revenue / prior_revenue - 1),
                            100 * (rd / prior_rd - 1), cash)
    return {**result, "rubric_version": "stability-half-year-v1"}

