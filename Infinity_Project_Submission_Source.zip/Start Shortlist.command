#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
sh ./start.sh "$@"
