INFINITY JOB SHORTLIST — PORTABLE EDITION

1. Extract this ZIP into a normal writable folder. Do not run inside the ZIP.
2. Install Python 3.11 or newer from https://www.python.org/downloads/ if needed.
3. Windows: double-click Start Shortlist.cmd.
   macOS: open Start Shortlist.command, or run: sh start.sh
   Linux / server: run: sh start.sh --no-browser
4. On a new machine, enter the separate transfer password ONCE when prompted.
   The first launch installs dependencies and opens http://localhost:8080/live.

No IBM API key, Bob IDE, PowerShell, local AI model or repeated demo-token entry
is required for local use. Internet and the existing active IBM instance ARE required.
Both agents stay deployed in IBM; this app reconnects to the existing lead agent
and its Company Assessment collaborator using signed ten-minute tokens.

The personal ZIP has an ENCRYPTED connection backup. Keep its transfer password
separate and private. The code-only ZIP has no signing credentials.

Search: HRIS, Python / United States — all 50 states / Focus Any / Experience Any.
Quick search reuses data for 15 minutes; Check employer boards now forces a refresh.
The first nationwide collection and IBM agent responses can still take time.

Full setup, SSH/server/Docker steps, troubleshooting and credential recovery:
PORTABLE_SETUP.md
